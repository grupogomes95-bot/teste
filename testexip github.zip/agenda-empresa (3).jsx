import { useState, useRef } from "react";

const INITIAL_USERS = {
  admin:   { id:"admin",   role:"admin",   name:"Empresa",        color:"#2563eb", bg:"#eff6ff", password:"admin123", photo:null, status:"" },
  colab1:  { id:"colab1",  role:"colab",   name:"Colaborador 1",  color:"#7c3aed", bg:"#f5f3ff", password:"colab1",   photo:null, status:"" },
  colab2:  { id:"colab2",  role:"colab",   name:"Colaborador 2",  color:"#0891b2", bg:"#ecfeff", password:"colab2",   photo:null, status:"" },
  colab3:  { id:"colab3",  role:"colab",   name:"Colaborador 3",  color:"#059669", bg:"#ecfdf5", password:"colab3",   photo:null, status:"" },
  colab4:  { id:"colab4",  role:"colab",   name:"Colaborador 4",  color:"#dc2626", bg:"#fef2f2", password:"colab4",   photo:null, status:"" },
  colab5:  { id:"colab5",  role:"colab",   name:"Colaborador 5",  color:"#d97706", bg:"#fffbeb", password:"colab5",   photo:null, status:"" },
  colab6:  { id:"colab6",  role:"colab",   name:"Colaborador 6",  color:"#be185d", bg:"#fdf2f8", password:"colab6",   photo:null, status:"" },
  client1:  { id:"client1",  role:"client", name:"Cliente 1",  color:"#0d9488", bg:"#f0fdfa", password:"cliente1",  photo:null, status:"" },
  client2:  { id:"client2",  role:"client", name:"Cliente 2",  color:"#0369a1", bg:"#f0f9ff", password:"cliente2",  photo:null, status:"" },
  client3:  { id:"client3",  role:"client", name:"Cliente 3",  color:"#7c3aed", bg:"#faf5ff", password:"cliente3",  photo:null, status:"" },
  client4:  { id:"client4",  role:"client", name:"Cliente 4",  color:"#b45309", bg:"#fffbeb", password:"cliente4",  photo:null, status:"" },
  client5:  { id:"client5",  role:"client", name:"Cliente 5",  color:"#be123c", bg:"#fff1f2", password:"cliente5",  photo:null, status:"" },
  client6:  { id:"client6",  role:"client", name:"Cliente 6",  color:"#166534", bg:"#f0fdf4", password:"cliente6",  photo:null, status:"" },
  client7:  { id:"client7",  role:"client", name:"Cliente 7",  color:"#1d4ed8", bg:"#eff6ff", password:"cliente7",  photo:null, status:"" },
  client8:  { id:"client8",  role:"client", name:"Cliente 8",  color:"#9d174d", bg:"#fdf2f8", password:"cliente8",  photo:null, status:"" },
  client9:  { id:"client9",  role:"client", name:"Cliente 9",  color:"#065f46", bg:"#ecfdf5", password:"cliente9",  photo:null, status:"" },
  client10: { id:"client10", role:"client", name:"Cliente 10",color:"#92400e", bg:"#fef3c7", password:"cliente10", photo:null, status:"" },
  client11: { id:"client11", role:"client", name:"Cliente 11",color:"#3730a3", bg:"#eef2ff", password:"cliente11", photo:null, status:"" },
  client12: { id:"client12", role:"client", name:"Cliente 12",color:"#0f766e", bg:"#f0fdfa", password:"cliente12", photo:null, status:"" },
  client13: { id:"client13", role:"client", name:"Cliente 13",color:"#b91c1c", bg:"#fef2f2", password:"cliente13", photo:null, status:"" },
  client14: { id:"client14", role:"client", name:"Cliente 14",color:"#4338ca", bg:"#eef2ff", password:"cliente14", photo:null, status:"" },
  client15: { id:"client15", role:"client", name:"Cliente 15",color:"#0e7490", bg:"#ecfeff", password:"cliente15", photo:null, status:"" },
  client16: { id:"client16", role:"client", name:"Cliente 16",color:"#15803d", bg:"#f0fdf4", password:"cliente16", photo:null, status:"" },
  client17: { id:"client17", role:"client", name:"Cliente 17",color:"#c2410c", bg:"#fff7ed", password:"cliente17", photo:null, status:"" },
  client18: { id:"client18", role:"client", name:"Cliente 18",color:"#6d28d9", bg:"#f5f3ff", password:"cliente18", photo:null, status:"" },
  client19: { id:"client19", role:"client", name:"Cliente 19",color:"#0c4a6e", bg:"#f0f9ff", password:"cliente19", photo:null, status:"" },
  client20: { id:"client20", role:"client", name:"Cliente 20",color:"#831843", bg:"#fdf2f8", password:"cliente20", photo:null, status:"" },
};

const MONTHS = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
const DAYS_OF_WEEK = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
const PRIORITY_COLORS = {
  alta:  { bg:"#fee2e2", text:"#991b1b", dot:"#dc2626", label:"Alta" },
  media: { bg:"#fef9c3", text:"#854d0e", dot:"#ca8a04", label:"Média" },
  baixa: { bg:"#dcfce7", text:"#166534", dot:"#16a34a", label:"Baixa" },
};

const today = new Date();
function getDaysInMonth(y,m){ return new Date(y,m+1,0).getDate(); }
function getFirstDay(y,m){ return new Date(y,m,1).getDay(); }
function fmtKey(y,m,d){ return `${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`; }

// ── LOGO ──────────────────────────────────────────────────────────────────
function GrupoGomesLogo({ height = 48 }) {
  const gSize = Math.round(height * 1.5);
  return (
    <div style={{ display:"flex",alignItems:"center",gap:Math.round(height*0.18) }}>
      <div style={{ width:gSize,height:gSize,borderRadius:Math.round(gSize*0.12),background:"#fff",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>
        <span style={{ fontSize:Math.round(gSize*0.65),fontWeight:900,color:"#1e3a5f",fontFamily:"Georgia,serif",lineHeight:1 }}>G</span>
      </div>
      <div style={{ display:"flex",flexDirection:"column",justifyContent:"flex-end",lineHeight:1.05,alignSelf:"flex-end",paddingBottom:Math.round(height*0.18) }}>
        <span style={{ fontFamily:"'Segoe UI',Arial,sans-serif",fontSize:Math.round(height*0.243),fontWeight:400,color:"#fff",letterSpacing:"0.18em",textTransform:"uppercase",marginLeft:3,marginBottom:1 }}>GRUPO</span>
        <span style={{ fontFamily:"'Segoe UI',Arial,sans-serif",fontSize:Math.round(height*0.414),fontWeight:800,color:"#fff",letterSpacing:"0.12em",textTransform:"uppercase" }}>GOMES</span>
      </div>
    </div>
  );
}
function Avatar({ user, size=40, onClick }) {
  const initials = user.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase();
  return (
    <div onClick={onClick}
      style={{ width:size,height:size,borderRadius:"50%",overflow:"hidden",flexShrink:0,
        border:`2.5px solid ${user.color}`, cursor:onClick?"pointer":"default",
        background:user.bg,display:"flex",alignItems:"center",justifyContent:"center",
        fontSize:size*0.35, fontWeight:800,color:user.color,position:"relative" }}>
      {user.photo
        ? <img src={user.photo} alt="" style={{ width:"100%",height:"100%", objectFit:"cover" }}/>
        : <span>{initials}</span>
      }
      {onClick && (
        <div style={{ position:"absolute",inset:0,background:"rgba(0,0,0,0)",display:"flex",alignItems:"center",justifyContent:"center",
          transition:"background .15s" }}
          onMouseEnter={e=>e.currentTarget.style.background="rgba(0,0,0,0.35)"}
          onMouseLeave={e=>e.currentTarget.style.background="rgba(0,0,0,0)"}>
          <span style={{ color:"#fff",fontSize:size*0.28,opacity:0,transition:"opacity .15s" }}
            onMouseEnter={e=>{ e.currentTarget.style.opacity="1"; }}
            onMouseLeave={e=>{ e.currentTarget.style.opacity="0"; }}>
            📷
          </span>
        </div>
      )}
    </div>
  );
}

// ── MODAL PERFIL ──────────────────────────────────────────────────────────
function ProfileModal({ user, onSave, onClose }) {
  const [photo, setPhoto] = useState(user.photo || null);
  const [status, setStatus] = useState(user.status || "");
  const [name, setName] = useState(user.name || "");
  const [dragging, setDragging] = useState(false);
  const fileRef = useRef();

  function handleFile(file) {
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = e => setPhoto(e.target.result);
    reader.readAsDataURL(file);
  }

  function handleDrop(e) {
    e.preventDefault(); setDragging(false);
    handleFile(e.dataTransfer.files[0]);
  }

  function removePhoto() { setPhoto(null); }

  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(15,23,42,.65)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:2000,padding:16 }}
      onClick={e=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div style={{ background:"#fff",borderRadius:24,padding:28,width:"100%",maxWidth:440,boxShadow:"0 24px 64px rgba(0,0,0,.3)" }}>

        {/* Header */}
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:24 }}>
          <div>
            <div style={{ fontSize:18, fontWeight:800,color:"#1e293b" }}>✏️ Editar Perfil</div>
            <div style={{ fontSize:12,color:"#94a3b8",marginTop:2 }}>Foto, nome e status</div>
          </div>
          <button onClick={onClose} style={{ width:32,height:32,borderRadius:8,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:18,color:"#64748b",display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
        </div>

        {/* Foto */}
        <div style={{ textAlign:"center",marginBottom:24 }}>
          {/* Preview */}
          <div style={{ position:"relative",display:"inline-block",marginBottom:16 }}>
            <div style={{ width:96,height:96,borderRadius:"50%",overflow:"hidden",border:`3px solid ${user.color}`,
              background:user.bg,display:"flex",alignItems:"center",justifyContent:"center",
              fontSize:36, fontWeight:800,color:user.color,margin:"0 auto" }}>
              {photo
                ? <img src={photo} alt="" style={{ width:"100%",height:"100%", objectFit:"cover" }}/>
                : <span>{name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase() || "?"}</span>
              }
            </div>
            {photo && (
              <button onClick={removePhoto}
                style={{ position:"absolute",top:-4,right:-4,width:24,height:24,borderRadius:"50%",background:"#ef4444",border:"2px solid #fff",cursor:"pointer",fontSize:12,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center" }}>
                ×
              </button>
            )}
          </div>

          {/* Drop zone */}
          <div
            onDragOver={e=>{ e.preventDefault(); setDragging(true); }}
            onDragLeave={()=>setDragging(false)}
            onDrop={handleDrop}
            onClick={()=>fileRef.current.click()}
            style={{ border:`2px dashed ${dragging ? user.color : "#cbd5e1"}`,borderRadius:12,padding:"16px 20px",
              cursor:"pointer",background:dragging ? user.bg : "#f8fafc",transition:"all .15s" }}>
            <div style={{ fontSize:24,marginBottom:6 }}>🖼️</div>
            <div style={{ fontSize:13,color:"#64748b", fontWeight:500 }}>Clique ou arraste uma foto aqui</div>
            <div style={{ fontSize:11,color:"#94a3b8",marginTop:3 }}>JPG, PNG ou GIF • max 5MB</div>
          </div>
          <input ref={fileRef} type="file" accept="image/*" style={{ display:"none" }}
            onChange={e=>handleFile(e.target.files[0])}/>
        </div>

        {/* Nome */}
        <div style={{ marginBottom:14 }}>
          <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>Nome / Cargo</label>
          <input value={name} onChange={e=>setName(e.target.value)} placeholder="Seu nome ou cargo..."
            style={{ width:"100%",padding:"10px 14px",borderRadius:10,border:`1.5px solid ${name ? user.color : "#e2e8f0"}`,fontSize:14,outline:"none",boxSizing:"border-box" }}/>
        </div>

        {/* Status */}
        <div style={{ marginBottom:22 }}>
          <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>
            💬 Status / Frase Pessoal
          </label>
          <textarea value={status} onChange={e=>setStatus(e.target.value.slice(0,120))}
            placeholder="Ex: Focado nos resultados! 🚀  |  Em reuniões até as 15h  |  Hoje é dia de entrega!"
            rows={3}
            style={{ width:"100%",padding:"10px 14px",borderRadius:10,border:`1.5px solid ${status ? user.color : "#e2e8f0"}`,fontSize:13,outline:"none",resize:"none",boxSizing:"border-box",fontFamily:"inherit" }}/>
          <div style={{ textAlign:"right",fontSize:11,color:"#94a3b8",marginTop:3 }}>{status.length}/120</div>
        </div>

        {/* Botões */}
        <div style={{ display:"flex",gap:10 }}>
          <button onClick={onClose} style={{ flex:1,padding:"11px 0",borderRadius:10,border:"1.5px solid #e2e8f0",background:"#f8fafc",color:"#64748b",cursor:"pointer",fontSize:13,fontWeight:600 }}>Cancelar</button>
          <button onClick={() => onSave({ photo, status, name })}
            style={{ flex:2,padding:"11px 0",borderRadius:10,border:"none",background:`linear-gradient(135deg,${user.color},${user.color}cc)`,color:"#fff",cursor:"pointer",fontSize:13,fontWeight:700 }}>
            💾 Salvar Perfil
          </button>
        </div>
      </div>
    </div>
  );
}

// ── CARD DE PERFIL (exibição no topo da agenda) ────────────────────────────
function ProfileCard({ user, onEdit }) {
  return (
    <div style={{ background:"#fff",borderRadius:16,border:`1px solid ${user.color}22`,padding:"16px 20px",
      marginBottom:18,display:"flex",alignItems:"center",gap:16,boxShadow:"0 1px 4px rgba(0,0,0,.06)",
      position:"relative",overflow:"hidden" }}>
      {/* Barra de cor lateral */}
      <div style={{ position:"absolute",left:0,top:0,bottom:0,width:4,background:user.color,borderRadius:"4px 0 0 4px" }}/>

      <Avatar user={user} size={58} onClick={onEdit}/>


      <div style={{ flex:1,minWidth:0 }}>
        <div style={{ display:"flex",alignItems:"center",gap:8,flexWrap:"wrap" }}>
          <span style={{ fontSize:17, fontWeight:800,color:"#1e293b" }}>{user.name}</span>
          {user.role === "admin" && (
            <span style={{ fontSize:10,padding:"2px 8px",borderRadius:10,background:"#eff6ff",color:"#2563eb",fontWeight:700,border:"1px solid #bfdbfe" }}>👑 CEO</span>
          )}
        </div>
        {user.status ? (
          <div style={{ fontSize:13,color:"#64748b",marginTop:4,fontStyle:"italic",display:"flex",alignItems:"flex-start",gap:5 }}>
            <span style={{ color:user.color,flexShrink:0 }}>💬</span>
            <span style={{ lineHeight:1.4 }}>{user.status}</span>
          </div>
        ) : (
          <div style={{ fontSize:12,color:"#cbd5e1",marginTop:4,fontStyle:"italic" }}>Nenhum status definido — clique em Editar Perfil</div>
        )}
      </div>

      <button onClick={onEdit}
        style={{ padding:"7px 14px",borderRadius:9,border:`1.5px solid ${user.color}44`,background:user.bg,
          color:user.color,cursor:"pointer",fontSize:12,fontWeight:700,whiteSpace:"nowrap",flexShrink:0 }}>
        ✏️ Editar Perfil
      </button>
    </div>
  );
}

// ── LOGIN USER PICKER (tabbed: Empresa/Colabs | Clientes) ────────────────
function LoginUserPicker({ users, sel, setSel, setPw, setErr }) {
  const [tab, setTab] = useState("equipe");
  const equipe = Object.values(users).filter(u => u.role === "admin" || u.role === "colab");
  const clientes = Object.values(users).filter(u => u.role === "client");

  function pick(id){ setSel(id); setPw(""); setErr(""); }

  return (
    <div style={{ marginBottom:20 }}>
      <label style={{ fontSize:11,fontWeight:700,color:"#94a3b8",display:"block",marginBottom:10,textTransform:"uppercase",letterSpacing:".8px" }}>Quem é você?</label>
      {/* Tabs */}
      <div style={{ display:"flex",gap:6,marginBottom:12 }}>
        <button onClick={()=>setTab("equipe")}
          style={{ flex:1,padding:"7px 0",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:700,
            background: tab==="equipe" ? "#2563eb" : "rgba(255,255,255,0.08)",
            color: tab==="equipe" ? "#fff" : "#94a3b8" }}>
          👥 Equipe
        </button>
        <button onClick={()=>setTab("clientes")}
          style={{ flex:1,padding:"7px 0",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:700,
            background: tab==="clientes" ? "#0d9488" : "rgba(255,255,255,0.08)",
            color: tab==="clientes" ? "#fff" : "#94a3b8" }}>
          🤝 Clientes
        </button>
      </div>
      {/* Grid */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr",gap:8,maxHeight:220,overflowY:"auto" }}>
        {(tab==="equipe" ? equipe : clientes).map(u => (
          <button key={u.id} onClick={()=>pick(u.id)}
            style={{ padding:"10px 10px",borderRadius:10,border:`2px solid ${sel===u.id ? u.color : "rgba(255,255,255,0.08)"}`,
              background:sel===u.id ? `${u.color}22` : "rgba(255,255,255,0.04)",
              color:sel===u.id ? u.color : "#94a3b8",cursor:"pointer",fontSize:12, fontWeight:sel===u.id?700:500,
              display:"flex",alignItems:"center",gap:8, textAlign:"left" }}>
            <div style={{ width:28,height:28,borderRadius:"50%",overflow:"hidden",border:`1.5px solid ${u.color}66`,flexShrink:0,
              background:u.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11, fontWeight:800,color:u.color }}>
              {u.photo
                ? <img src={u.photo} alt="" style={{ width:"100%",height:"100%", objectFit:"cover" }}/>
                : <span>{u.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</span>
              }
            </div>
            <span style={{ overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{u.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── LOGIN ─────────────────────────────────────────────────────────────────
function LoginScreen({ users, onLogin }) {
  const [sel, setSel] = useState("admin");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [show, setShow] = useState(false);
  const userList = Object.values(users);
  const selected = users[sel];

  function handle() {
    if (pw === selected.password) { setErr(""); onLogin(sel); }
    else { setErr("Senha incorreta. Tente novamente."); setPw(""); }
  }

  return (
    <div style={{ minHeight:"100vh",background:"#000",display:"flex",alignItems:"center",justifyContent:"center",padding:16 }}>
      <div style={{ width:"100%",maxWidth:440 }}>
        <div style={{ textAlign:"center",marginBottom:32 }}>
          <div style={{ marginBottom:20,display:"flex",alignItems:"center",justifyContent:"center" }}>
            <GrupoGomesLogo height={80}/>
          </div>
          <p style={{ color:"#94a3b8",fontSize:14,marginTop:4 }}>Selecione seu perfil e insira sua senha</p>
        </div>
        <div style={{ background:"rgba(255,255,255,0.06)", backdropFilter:"blur(12px)",borderRadius:20,border:"1px solid rgba(255,255,255,0.12)",padding:28,boxShadow:"0 24px 48px rgba(0,0,0,0.4)" }}>
          <LoginUserPicker users={users} sel={sel} setSel={setSel} setPw={setPw} setErr={setErr}/>
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11,fontWeight:700,color:"#94a3b8",display:"block",marginBottom:8,textTransform:"uppercase",letterSpacing:".8px" }}>Senha</label>
            <div style={{ position:"relative" }}>
              <input type={show?"text":"password"} value={pw}
                onChange={e=>{ setPw(e.target.value); setErr(""); }}
                onKeyDown={e=>e.key==="Enter"&&handle()}
                placeholder="Digite sua senha"
                style={{ width:"100%",padding:"12px 44px 12px 14px",borderRadius:10,border:`1.5px solid ${err?"#ef4444":"rgba(255,255,255,0.12)"}`,background:"rgba(255,255,255,0.07)",color:"#f1f5f9",fontSize:15,outline:"none",boxSizing:"border-box" }}/>
              <button onClick={()=>setShow(p=>!p)} style={{ position:"absolute",right:12,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",fontSize:16,color:"#64748b" }}>{show?"🙈":"👁️"}</button>
            </div>
            {err && <p style={{ color:"#f87171",fontSize:13,margin:"6px 0 0" }}>⚠️ {err}</p>}
          </div>
          <button onClick={handle}
            style={{ width:"100%",padding:"13px 0",borderRadius:12,border:"none",background:`linear-gradient(135deg,${selected.color},${selected.color}cc)`,color:"#fff",fontSize:15,fontWeight:700,cursor:"pointer" }}>
            Entrar →
          </button>
        </div>
        <p style={{ textAlign:"center",color:"#475569",fontSize:12,marginTop:20 }}>🔒 Cada colaborador acessa apenas sua própria agenda</p>
      </div>
    </div>
  );
}

// ── MODAL TAREFA ──────────────────────────────────────────────────────────
function TaskModal({ person, selectedDay, month, year, editingEvent, form, setForm, onSave, onDelete, onClose, users, isAdmin }) {
  const colabs = Object.values(users).filter(u=>u.role==="colab");
  const clients = Object.values(users).filter(u=>u.role==="client");
  function toggleColab(id) {
    const cur = form.tagged||[];
    setForm(f=>({...f, tagged: cur.includes(id) ? cur.filter(x=>x!==id) : [...cur,id]}));
  }
  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(15,23,42,.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000,padding:16 }}
      onClick={e=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div style={{ background:"#fff",borderRadius:20,padding:26,width:"100%",maxWidth:500,boxShadow:"0 20px 60px rgba(0,0,0,.3)",maxHeight:"92vh",overflowY:"auto" }}>
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:18 }}>
          <div style={{ display:"flex",alignItems:"center",gap:10 }}>
            <Avatar user={person} size={34}/>
            <div>
              <div style={{ fontSize:16, fontWeight:800,color:"#1e293b" }}>{editingEvent?"✏️ Editar Tarefa":"➕ Nova Tarefa"}</div>
              <div style={{ fontSize:11,color:person.color,fontWeight:600 }}>{person.name} • {selectedDay} de {MONTHS[month]}</div>
            </div>
          </div>
          <button onClick={onClose} style={{ width:30,height:30,borderRadius:7,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:17,color:"#64748b",display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
        </div>
        <div style={{ display:"flex",flexDirection:"column",gap:13 }}>
          <div>
            <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".5px" }}>Título *</label>
            <input value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="Ex: Reunião de equipe, Entrega de projeto..."
              style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:`1.5px solid ${form.title?person.color:"#e2e8f0"}`,fontSize:13,outline:"none",boxSizing:"border-box" }}/>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr",gap:10 }}>
            <div>
              <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".5px" }}>Horário</label>
              <input type="time" value={form.time} onChange={e=>setForm(f=>({...f,time:e.target.value}))}
                style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",boxSizing:"border-box" }}/>
            </div>
            <div>
              <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".5px" }}>Categoria</label>
              <input value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))} placeholder="Ex: Reunião, Projeto..."
                style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",boxSizing:"border-box" }}/>
            </div>
          </div>
          <div>
            <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:6,textTransform:"uppercase",letterSpacing:".5px" }}>Prioridade</label>
            <div style={{ display:"flex",gap:7 }}>
              {Object.entries(PRIORITY_COLORS).map(([k,v])=>(
                <button key={k} onClick={()=>setForm(f=>({...f,priority:k}))}
                  style={{ flex:1,padding:"7px 0",borderRadius:8,border:`2px solid ${form.priority===k?v.dot:"#e2e8f0"}`,background:form.priority===k?v.bg:"#f8fafc",color:form.priority===k?v.text:"#94a3b8",cursor:"pointer",fontSize:12, fontWeight:form.priority===k?700:500 }}>
                  {v.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".5px" }}>Descrição / Observações</label>
            <textarea value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} placeholder="Detalhes, links, instruções..." rows={3}
              style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",resize:"vertical",boxSizing:"border-box",fontFamily:"inherit" }}/>
          </div>
          {isAdmin && (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {/* Colaboradores */}
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#1e293b",display:"block",marginBottom:6,textTransform:"uppercase",letterSpacing:".5px" }}>👥 Marcar Colaboradores</label>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr",gap:7 }}>
                  {colabs.map(u=>{
                    const tagged=(form.tagged||[]).includes(u.id);
                    return (
                      <button key={u.id} onClick={()=>toggleColab(u.id)}
                        style={{ padding:"8px 10px",borderRadius:9,border:`2px solid ${tagged?u.color:"#e2e8f0"}`,background:tagged?u.bg:"#f8fafc",color:tagged?u.color:"#94a3b8",cursor:"pointer",fontSize:12, fontWeight:tagged?700:500,display:"flex",alignItems:"center",gap:8 }}>
                        <Avatar user={u} size={24}/>
                        <span style={{ overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{u.name}</span>
                        {tagged && <span style={{ marginLeft:"auto",color:u.color }}>✓</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
              {/* Clientes */}
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#0d9488",display:"block",marginBottom:6,textTransform:"uppercase",letterSpacing:".5px" }}>🤝 Marcar Clientes</label>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr",gap:7,maxHeight:160,overflowY:"auto" }}>
                  {clients.map(u=>{
                    const tagged=(form.tagged||[]).includes(u.id);
                    return (
                      <button key={u.id} onClick={()=>toggleColab(u.id)}
                        style={{ padding:"8px 10px",borderRadius:9,border:`2px solid ${tagged?u.color:"#e2e8f0"}`,background:tagged?u.bg:"#f8fafc",color:tagged?u.color:"#94a3b8",cursor:"pointer",fontSize:12, fontWeight:tagged?700:500,display:"flex",alignItems:"center",gap:8 }}>
                        <Avatar user={u} size={24}/>
                        <span style={{ overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap" }}>{u.name}</span>
                        {tagged && <span style={{ marginLeft:"auto",color:u.color }}>✓</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
              {(form.tagged||[]).length>0 && (
                <div style={{ padding:"8px 12px",borderRadius:8,background:"#eff6ff",border:"1px solid #bfdbfe",fontSize:11,color:"#1d4ed8" }}>
                  📌 Será espelhado para: <strong>{(form.tagged||[]).map(id=>users[id]?.name).join(", ")}</strong>
                </div>
              )}
            </div>
          )}
          <div style={{ display:"flex",gap:8,marginTop:4 }}>
            {editingEvent && <button onClick={onDelete} style={{ padding:"10px 14px",borderRadius:9,border:"1.5px solid #fee2e2",background:"#fff",color:"#dc2626",cursor:"pointer",fontSize:13,fontWeight:600 }}>🗑️</button>}
            <button onClick={onClose} style={{ flex:1,padding:"10px 0",borderRadius:9,border:"1.5px solid #e2e8f0",background:"#f8fafc",color:"#64748b",cursor:"pointer",fontSize:13,fontWeight:600 }}>Cancelar</button>
            <button onClick={onSave} disabled={!form.title.trim()} style={{ flex:2,padding:"10px 0",borderRadius:9,border:"none",background:form.title.trim()?person.color:"#e2e8f0",color:"#fff", cursor:form.title.trim()?"pointer":"not-allowed",fontSize:13,fontWeight:700 }}>
              {editingEvent?"💾 Salvar":"✅ Adicionar"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── CALENDÁRIO ────────────────────────────────────────────────────────────
function CalendarGrid({ person, year, month, getEventsDay, daysInMonth, firstDay, onAddDay, onEditEvent }) {
  return (
    <div style={{ background:"#fff",borderRadius:16,boxShadow:"0 1px 4px rgba(0,0,0,.08)",overflow:"hidden",border:"1px solid #e2e8f0" }}>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)",background:"#f8fafc", borderBottom:"1px solid #e2e8f0" }}>
        {DAYS_OF_WEEK.map(d=><div key={d} style={{ padding:"10px 0", textAlign:"center",fontSize:11,fontWeight:700,color:"#64748b",letterSpacing:".5px",textTransform:"uppercase" }}>{d}</div>)}
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)" }}>
        {Array.from({length:firstDay}).map((_,i)=><div key={`e${i}`} style={{ minHeight:110, borderRight:"1px solid #f1f5f9", borderBottom:"1px solid #f1f5f9",background:"#fafafa" }}/>)}
        {Array.from({length:daysInMonth},(_,i)=>i+1).map(day=>{
          const evs=getEventsDay(day);
          const isToday=day===today.getDate()&&month===today.getMonth()&&year===today.getFullYear();
          return (
            <div key={day} onClick={()=>onAddDay(day)}
              style={{ minHeight:110, borderRight:"1px solid #f1f5f9", borderBottom:"1px solid #f1f5f9",padding:5,cursor:"pointer",background:isToday?person.bg:"#fff" }}>
              <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:3 }}>
                <span style={{ fontSize:12, fontWeight:isToday?800:500,background:isToday?person.color:"transparent",color:isToday?"#fff":"#374151",borderRadius:isToday?5:0,padding:isToday?"1px 5px":"0",minWidth:20, textAlign:"center" }}>{day}</span>
                {evs.length>0&&<span style={{ fontSize:10,color:person.color,fontWeight:700 }}>{evs.length}</span>}
              </div>
              {evs.slice(0,3).map(ev=>(
                <div key={ev.id} onClick={e=>{e.stopPropagation();onEditEvent(day,ev);}}
                  style={{ fontSize:10,padding:"2px 5px",borderRadius:4,marginBottom:2,
                    background:ev.fromAdmin?"#eff6ff":(PRIORITY_COLORS[ev.priority]?.bg||"#f1f5f9"),
                    color:ev.fromAdmin?"#1d4ed8":(PRIORITY_COLORS[ev.priority]?.text||"#374151"),
                    fontWeight:500, borderLeft:`3px solid ${ev.fromAdmin?"#2563eb":(PRIORITY_COLORS[ev.priority]?.dot||"#94a3b8")}`,
                    overflow:"hidden",whiteSpace:"nowrap",textOverflow:"ellipsis",cursor:"pointer",display:"flex",alignItems:"center",gap:3 }}>
                  {ev.fromAdmin&&<span>📌</span>}
                  {ev.time&&<span style={{opacity:.7}}>{ev.time}</span>}
                  <span style={{overflow:"hidden",textOverflow:"ellipsis"}}>{ev.title}</span>
                </div>
              ))}
              {evs.length>3&&<div style={{fontSize:10,color:person.color,fontWeight:600}}>+{evs.length-3} mais</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── LISTA ─────────────────────────────────────────────────────────────────
function ListView({ person, month, allEvents, onEdit, onDelete }) {
  if (!allEvents.length) return (
    <div style={{ background:"#fff",borderRadius:16,border:"1px solid #e2e8f0",padding:60, textAlign:"center" }}>
      <div style={{ fontSize:44,marginBottom:10 }}>📭</div>
      <div style={{ color:"#94a3b8",fontSize:14 }}>Nenhuma tarefa neste mês</div>
    </div>
  );
  return (
    <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
      {allEvents.map(({day,ev})=>(
        <div key={ev.id} style={{ background:"#fff",borderRadius:12,border:`1px solid ${ev.fromAdmin?"#bfdbfe":"#e2e8f0"}`,padding:"12px 16px",display:"flex",alignItems:"flex-start",gap:14 }}>
          <div style={{ background:ev.fromAdmin?"#eff6ff":person.bg,border:`2px solid ${ev.fromAdmin?"#2563eb":person.color}33`,borderRadius:9,padding:"5px 8px", textAlign:"center",minWidth:44 }}>
            <div style={{ fontSize:17, fontWeight:800,color:ev.fromAdmin?"#2563eb":person.color,lineHeight:1 }}>{day}</div>
            <div style={{ fontSize:9,color:"#94a3b8", fontWeight:500 }}>{MONTHS[month].slice(0,3)}</div>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ display:"flex",alignItems:"center",gap:7,flexWrap:"wrap" }}>
              {ev.fromAdmin&&<span style={{ fontSize:10,padding:"2px 8px",borderRadius:10,background:"#dbeafe",color:"#1d4ed8",fontWeight:700 }}>📌 Da Empresa</span>}
              <span style={{ fontSize:14,fontWeight:700,color:"#1e293b" }}>{ev.title}</span>
              <span style={{ fontSize:10,padding:"2px 7px",borderRadius:10,background:PRIORITY_COLORS[ev.priority]?.bg,color:PRIORITY_COLORS[ev.priority]?.text,fontWeight:600 }}>{PRIORITY_COLORS[ev.priority]?.label}</span>
              {ev.category&&<span style={{ fontSize:10,padding:"2px 7px",borderRadius:10,background:"#f1f5f9",color:"#64748b" }}>{ev.category}</span>}
              {ev.time&&<span style={{ fontSize:11,color:"#94a3b8" }}>🕐 {ev.time}</span>}
            </div>
            {ev.description&&<div style={{ fontSize:12,color:"#64748b",marginTop:3 }}>{ev.description}</div>}
          </div>
          {!ev.fromAdmin
            ? <div style={{ display:"flex",gap:5 }}>
                <button onClick={()=>onEdit(day,ev)} style={{ padding:"4px 9px",borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:11,color:"#64748b" }}>✏️</button>
                <button onClick={()=>onDelete(day,ev.id)} style={{ padding:"4px 9px",borderRadius:6,border:"1px solid #fee2e2",background:"#fff",cursor:"pointer",fontSize:11,color:"#dc2626" }}>🗑️</button>
              </div>
            : <div style={{ fontSize:10,color:"#93c5fd",padding:"4px 8px",borderRadius:6,background:"#eff6ff",border:"1px solid #dbeafe",whiteSpace:"nowrap" }}>🔒 Empresa</div>
          }
        </div>
      ))}
    </div>
  );
}

// ── SENHA ROW ─────────────────────────────────────────────────────────────
function PasswordRow({ user, onSave }) {
  const [pw, setPw] = useState(""); const [show, setShow] = useState(false); const [saved, setSaved] = useState(false);
  function handle(){ if(!pw.trim())return; onSave(pw.trim()); setSaved(true); setPw(""); setTimeout(()=>setSaved(false),2000); }
  return (
    <div style={{ background:"#f8fafc",borderRadius:12,padding:"12px 16px",border:`1.5px solid ${user.color}22` }}>
      <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:10 }}>
        <Avatar user={user} size={30}/>
        <span style={{ fontWeight:700,fontSize:13,color:"#1e293b" }}>{user.name}</span>
        <span style={{ fontSize:11,color:"#94a3b8", marginLeft:"auto" }}>Senha atual: •••••</span>
      </div>
      <div style={{ display:"flex",gap:8 }}>
        <div style={{ flex:1,position:"relative" }}>
          <input type={show?"text":"password"} value={pw} onChange={e=>setPw(e.target.value)} placeholder="Nova senha..."
            onKeyDown={e=>e.key==="Enter"&&handle()}
            style={{ width:"100%",padding:"8px 36px 8px 10px",borderRadius:8,border:`1.5px solid ${user.color}44`,fontSize:13,outline:"none",boxSizing:"border-box",background:"#fff" }}/>
          <button onClick={()=>setShow(p=>!p)} style={{ position:"absolute",right:8,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",cursor:"pointer",fontSize:13,color:"#94a3b8" }}>{show?"🙈":"👁️"}</button>
        </div>
        <button onClick={handle} disabled={!pw.trim()} style={{ padding:"8px 16px",borderRadius:8,border:"none",background:pw.trim()?user.color:"#e2e8f0",color:"#fff", cursor:pw.trim()?"pointer":"not-allowed",fontSize:12,fontWeight:700,whiteSpace:"nowrap" }}>
          {saved?"✓ Salvo!":"Salvar"}
        </button>
      </div>
    </div>
  );
}

// ── PAINEL ADMIN ──────────────────────────────────────────────────────────
function AdminPanel({ users, setUsers, events, setEvents, onLogout }) {
  const [activeTab, setActiveTab] = useState("admin");
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [view, setView] = useState("calendar");
  const [selectedDay, setSelectedDay] = useState(null);
  const [modal, setModal] = useState(false);
  const [editingEventId, setEditingEventId] = useState(null);
  const [form, setForm] = useState({title:"",description:"",time:"",priority:"media",category:"",tagged:[]});
  const [showSettings, setShowSettings] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const person = users[activeTab];
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDay(year, month);

  function getEventsDay(day){ return events[`${activeTab}::${fmtKey(year,month,day)}`]||[]; }
  function openAdd(day){ if(activeTab!=="admin") return; setSelectedDay(day); setEditingEventId(null); setForm({title:"",description:"",time:"",priority:"media",category:"",tagged:[]}); setModal(true); }
  function openEdit(day,ev){ if(activeTab!=="admin") return; setSelectedDay(day); setEditingEventId(ev.id); setForm({title:ev.title,description:ev.description||"",time:ev.time||"",priority:ev.priority||"media",category:ev.category||"",tagged:ev.tagged||[]}); setModal(true); }

  function saveEvent(){
    if(!form.title.trim()) return;
    const dateKey=fmtKey(year,month,selectedDay);
    const adminKey=`admin::${dateKey}`;
    const existingAdmin=events[adminKey]||[];
    const adminEv={...form,id:editingEventId||Date.now(),tagged:form.tagged||[]};
    let newEvents={...events};
    if(editingEventId){
      const oldEv=existingAdmin.find(e=>e.id===editingEventId);
      if(oldEv?.tagged) oldEv.tagged.forEach(cid=>{ const ck=`${cid}::${dateKey}`; newEvents[ck]=(newEvents[ck]||[]).filter(e=>e.mirrorOf!==editingEventId); });
      newEvents[adminKey]=existingAdmin.map(e=>e.id===editingEventId?adminEv:e);
    } else { newEvents[adminKey]=[...existingAdmin,adminEv]; }
    (form.tagged||[]).forEach(cid=>{
      const ck=`${cid}::${dateKey}`;
      const filtered=(newEvents[ck]||[]).filter(e=>e.mirrorOf!==editingEventId);
      newEvents[ck]=[...filtered,{id:Date.now()+Math.random(),title:adminEv.title,description:adminEv.description,time:adminEv.time,priority:adminEv.priority,category:adminEv.category,fromAdmin:true,mirrorOf:adminEv.id}];
    });
    setEvents(newEvents); setModal(false);
  }

  function deleteEvent(day,id){
    const dateKey=fmtKey(year,month,day); const adminKey=`admin::${dateKey}`;
    const ev=(events[adminKey]||[]).find(e=>e.id===id);
    let newEvents={...events};
    if(ev?.tagged) ev.tagged.forEach(cid=>{ const ck=`${cid}::${dateKey}`; newEvents[ck]=(newEvents[ck]||[]).filter(e=>e.mirrorOf!==id); });
    newEvents[adminKey]=(newEvents[adminKey]||[]).filter(e=>e.id!==id);
    setEvents(newEvents); setModal(false);
  }

  function getAllEventsMonth(){
    const r=[];
    for(let d=1;d<=daysInMonth;d++){ const key=`${activeTab}::${fmtKey(year,month,d)}`; (events[key]||[]).forEach(ev=>r.push({day:d,ev})); }
    return r.sort((a,b)=>a.day-b.day||(a.ev.time||"").localeCompare(b.ev.time||""));
  }
  function countMonth(uid){ let c=0; for(let d=1;d<=getDaysInMonth(year,month);d++) c+=(events[`${uid}::${fmtKey(year,month,d)}`]||[]).length; return c; }
  function prevMonth(){ if(month===0){setMonth(11);setYear(y=>y-1);}else setMonth(m=>m-1); }
  function nextMonth(){ if(month===11){setMonth(0);setYear(y=>y+1);}else setMonth(m=>m+1); }

  const allMonthEvents=getAllEventsMonth();
  const userList=Object.values(users);

  function saveProfile({photo,status,name}){
    setUsers(p=>({...p,[activeTab]:{...p[activeTab],photo,status,name}}));
    setShowProfile(false);
  }

  return (
    <div style={{ fontFamily:"'Inter','Segoe UI',sans-serif",minHeight:"100vh",background:"#f8fafc" }}>
      {/* HEADER */}
      <div style={{ background:"#000",padding:"0 20px",boxShadow:"0 2px 8px rgba(0,0,0,.6)" }}>
        <div style={{ maxWidth:1200,margin:"0 auto" }}>
          <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between", paddingTop:16, paddingBottom:10,flexWrap:"wrap",gap:10 }}>
            <div style={{ display:"flex",alignItems:"center",gap:12 }}>
              <Avatar user={users["admin"]} size={40} onClick={()=>{ setActiveTab("admin"); setShowProfile(true); }}/>
              <div>
                <GrupoGomesLogo height={42}/>
                <p style={{ color:"#94a3b8",fontSize:11,margin:"4px 0 0" }}>Painel CEO — acesso completo</p>
              </div>
            </div>
            <div style={{ display:"flex",gap:8 }}>
              <button onClick={()=>setView("calendar")} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:view==="calendar"?"#3b82f6":"#334155",color:view==="calendar"?"#fff":"#94a3b8" }}>📅 Calendário</button>
              <button onClick={()=>setView("list")} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:view==="list"?"#3b82f6":"#334155",color:view==="list"?"#fff":"#94a3b8" }}>📋 Lista</button>
              <button onClick={()=>setShowSettings(true)} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:"#111",color:"#94a3b8" }}>⚙️ Senhas</button>
              <button onClick={onLogout} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:"#111",color:"#f87171" }}>🚪 Sair</button>
            </div>
          </div>
          {/* Tabs - Equipe */}
          <div style={{ display:"flex",gap:2,overflowX:"auto" }}>
            {Object.values(users).filter(u=>u.role!=="client").map(u=>{
              const isActive=activeTab===u.id; const cnt=countMonth(u.id);
              return (
                <button key={u.id} onClick={()=>setActiveTab(u.id)}
                  style={{ padding:"7px 12px",borderRadius:"8px 8px 0 0",border:"none",cursor:"pointer",fontSize:11, fontWeight:isActive?700:500,whiteSpace:"nowrap",background:isActive?"#f8fafc":"transparent",color:isActive?u.color:"#94a3b8", borderBottom:isActive?`3px solid ${u.color}`:"3px solid transparent",display:"flex",alignItems:"center",gap:6 }}>
                  <div style={{ width:20,height:20,borderRadius:"50%",overflow:"hidden",border:`1.5px solid ${u.color}66`,flexShrink:0,background:u.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8, fontWeight:800,color:u.color }}>
                    {u.photo ? <img src={u.photo} alt="" style={{ width:"100%",height:"100%", objectFit:"cover" }}/> : <span>{u.name.slice(0,2)}</span>}
                  </div>
                  {u.name}
                  {cnt>0&&<span style={{ background:u.color,color:"#fff",borderRadius:10,padding:"1px 5px",fontSize:9 }}>{cnt}</span>}
                </button>
              );
            })}
          </div>
          {/* Tabs - Clientes */}
          <div style={{ display:"flex",gap:2,overflowX:"auto", borderTop:"1px solid #1e2a3a", paddingTop:3 }}>
            <span style={{ padding:"6px 8px",fontSize:10,color:"#0d9488",fontWeight:700,whiteSpace:"nowrap",flexShrink:0,alignSelf:"center" }}>🤝 Clientes:</span>
            {Object.values(users).filter(u=>u.role==="client").map(u=>{
              const isActive=activeTab===u.id; const cnt=countMonth(u.id);
              return (
                <button key={u.id} onClick={()=>setActiveTab(u.id)}
                  style={{ padding:"7px 12px",borderRadius:"8px 8px 0 0",border:"none",cursor:"pointer",fontSize:11, fontWeight:isActive?700:500,whiteSpace:"nowrap",background:isActive?"#f8fafc":"transparent",color:isActive?u.color:"#94a3b8", borderBottom:isActive?`3px solid ${u.color}`:"3px solid transparent",display:"flex",alignItems:"center",gap:6 }}>
                  <div style={{ width:20,height:20,borderRadius:"50%",overflow:"hidden",border:`1.5px solid ${u.color}66`,flexShrink:0,background:u.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8, fontWeight:800,color:u.color }}>
                    {u.photo ? <img src={u.photo} alt="" style={{ width:"100%",height:"100%", objectFit:"cover" }}/> : <span>{u.name.slice(0,2)}</span>}
                  </div>
                  {u.name}
                  {cnt>0&&<span style={{ background:u.color,color:"#fff",borderRadius:10,padding:"1px 5px",fontSize:9 }}>{cnt}</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* BODY */}
      <div style={{ maxWidth:1200,margin:"0 auto",padding:"20px 16px" }}>
        {/* Profile card */}
        <ProfileCard user={person} onEdit={()=>setShowProfile(true)}/>

        {/* Controls */}
        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16,flexWrap:"wrap",gap:10 }}>
          {activeTab==="admin" && (
            <div style={{ display:"flex",alignItems:"center",gap:8,padding:"8px 14px",background:"#fff",borderRadius:10,border:"1px solid #e2e8f0",fontSize:12,color:"#64748b" }}>
              <span style={{ width:10,height:10,background:"#2563eb",borderRadius:2,display:"inline-block" }}></span> Normal
              <span style={{ marginLeft:8 }}>📌</span> Marcado p/ colaboradores
            </div>
          )}
          <div style={{ display:"flex",alignItems:"center",gap:8, marginLeft:"auto" }}>
            <button onClick={prevMonth} style={{ width:34,height:34,borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center" }}>‹</button>
            <span style={{ fontWeight:700,fontSize:15,color:"#1e293b",minWidth:150,textAlign:"center" }}>{MONTHS[month]} {year}</span>
            <button onClick={nextMonth} style={{ width:34,height:34,borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center" }}>›</button>
            <button onClick={()=>{setMonth(today.getMonth());setYear(today.getFullYear());}} style={{ padding:"6px 12px",borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:12,color:"#64748b" }}>Hoje</button>
          </div>
        </div>

        {view==="calendar"&&<CalendarGrid person={person} year={year} month={month} getEventsDay={getEventsDay} daysInMonth={daysInMonth} firstDay={firstDay} onAddDay={openAdd} onEditEvent={openEdit}/>}
        {view==="list"&&<ListView person={person} month={month} allEvents={allMonthEvents} onEdit={openEdit} onDelete={(day,id)=>deleteEvent(day,id)}/>}
      </div>

      {modal&&<TaskModal person={person} selectedDay={selectedDay} month={month} year={year} editingEvent={editingEventId} form={form} setForm={setForm} onSave={saveEvent} onDelete={()=>deleteEvent(selectedDay,editingEventId)} onClose={()=>setModal(false)} users={users} isAdmin={activeTab==="admin"}/>}

      {showProfile&&<ProfileModal user={person} onSave={saveProfile} onClose={()=>setShowProfile(false)}/>}

      {showSettings&&(
        <div style={{ position:"fixed",inset:0,background:"rgba(15,23,42,.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000,padding:16 }}
          onClick={e=>{if(e.target===e.currentTarget)setShowSettings(false);}}>
          <div style={{ background:"#fff",borderRadius:20,padding:28,width:"100%",maxWidth:500,boxShadow:"0 20px 60px rgba(0,0,0,.3)",maxHeight:"85vh",overflowY:"auto" }}>
            <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:22 }}>
              <div><div style={{ fontSize:18,fontWeight:800,color:"#1e293b" }}>🔐 Gerenciar Senhas</div><div style={{ fontSize:12,color:"#94a3b8",marginTop:2 }}>Altere as senhas de acesso de cada agenda</div></div>
              <button onClick={()=>setShowSettings(false)} style={{ width:30,height:30,borderRadius:7,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:17,display:"flex",alignItems:"center",justifyContent:"center",color:"#64748b" }}>×</button>
            </div>
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {Object.values(users).map(u=><PasswordRow key={u.id} user={u} onSave={pw=>setUsers(p=>({...p,[u.id]:{...p[u.id],password:pw}}))}/>)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}



// ── SISTEMA DE UNIDADES ───────────────────────────────────────────────────
const NOTA_LABELS = ["","⭐","⭐⭐","⭐⭐⭐","⭐⭐⭐⭐","⭐⭐⭐⭐⭐"];


function ActModal({actForm,setActForm,editActId,setEditActId,setActModal,clientColor,saveAct}) {
  const STATUS_CFG = {
    feito:    {bg:"#dcfce7",text:"#166534",dot:"#16a34a",label:"✅ Feito"},
    pendente: {bg:"#fef9c3",text:"#854d0e",dot:"#ca8a04",label:"🔄 Em andamento"},
    longo:    {bg:"#eff6ff",text:"#1d4ed8",dot:"#2563eb",label:"📅 Longo prazo"},
  };
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(15,23,42,.7)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:3000,padding:16}}
      onClick={e=>{if(e.target===e.currentTarget)setActModal(false);}}>
      <div style={{background:"#fff",borderRadius:18,padding:24,width:"100%",maxWidth:420,boxShadow:"0 20px 60px rgba(0,0,0,.3)"}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:16}}>
          <div style={{fontSize:16,fontWeight:800,color:"#1e293b"}}>{editActId?"✏️ Editar":"➕ Nova"} Atividade</div>
          <button onClick={()=>setActModal(false)} style={{width:28,height:28,borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:16,color:"#64748b",display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:11}}>
          <input value={actForm.title} onChange={e=>setActForm(f=>({...f,title:e.target.value}))} placeholder="Título da atividade *"
            style={{padding:"8px 12px",borderRadius:8,border:`1.5px solid ${actForm.title?"#0d9488":"#e2e8f0"}`,fontSize:13,outline:"none"}}/>
          <textarea value={actForm.desc} onChange={e=>setActForm(f=>({...f,desc:e.target.value}))} placeholder="Descrição..." rows={2}
            style={{padding:"8px 12px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",resize:"vertical",fontFamily:"inherit"}}/>
          <div>
            <label style={{fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px"}}>Data</label>
            <input type="date" value={actForm.data||""} onChange={e=>setActForm(f=>({...f,data:e.target.value}))}
              style={{width:"100%",padding:"8px 12px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",boxSizing:"border-box"}}/>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div>
              <label style={{fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px"}}>▶ Início</label>
              <input type="time" value={actForm.horaIni||""} onChange={e=>setActForm(f=>({...f,horaIni:e.target.value}))}
                style={{width:"100%",padding:"8px 12px",borderRadius:8,border:"1.5px solid #eff6ff",fontSize:13,outline:"none",boxSizing:"border-box"}}/>
            </div>
            <div>
              <label style={{fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px"}}>■ Término</label>
              <input type="time" value={actForm.horaFim||""} onChange={e=>setActForm(f=>({...f,horaFim:e.target.value}))}
                style={{width:"100%",padding:"8px 12px",borderRadius:8,border:"1.5px solid #f0fdf4",fontSize:13,outline:"none",boxSizing:"border-box"}}/>
            </div>
          </div>
          <div style={{display:"flex",gap:6}}>
            {Object.entries(STATUS_CFG).map(([k,v])=>(
              <button key={k} onClick={()=>setActForm(f=>({...f,status:k}))}
                style={{flex:1,padding:"6px 3px",borderRadius:7,border:`2px solid ${actForm.status===k?v.dot:"#e2e8f0"}`,background:actForm.status===k?v.bg:"#f8fafc",color:actForm.status===k?v.text:"#94a3b8",cursor:"pointer",fontSize:10,fontWeight:actForm.status===k?700:500}}>
                {v.label}
              </button>
            ))}
          </div>
          <div style={{display:"flex",gap:6}}>
            {[["agora","⏰ Agora","#f59e0b","#fef3c7","#92400e"],["longo","🔭 Longo prazo","#2563eb","#eff6ff","#1d4ed8"]].map(([k,l,dot,bg,text])=>(
              <button key={k} onClick={()=>setActForm(f=>({...f,prazo:k}))}
                style={{flex:1,padding:"6px 0",borderRadius:7,border:`2px solid ${actForm.prazo===k?dot:"#e2e8f0"}`,background:actForm.prazo===k?bg:"#f8fafc",color:actForm.prazo===k?text:"#94a3b8",cursor:"pointer",fontSize:11,fontWeight:actForm.prazo===k?700:500}}>
                {l}
              </button>
            ))}
          </div>
          <div style={{display:"flex",gap:7,marginTop:4}}>
            <button onClick={()=>{setActModal(false);setEditActId(null);setActForm({title:"",desc:"",status:"pendente",prazo:"agora",data:"",horaIni:"",horaFim:""});}} style={{flex:1,padding:"9px 0",borderRadius:8,border:"1.5px solid #e2e8f0",background:"#f8fafc",color:"#64748b",cursor:"pointer",fontSize:12,fontWeight:600}}>Cancelar</button>
            <button onClick={saveAct} disabled={!actForm.title.trim()} style={{flex:2,padding:"9px 0",borderRadius:8,border:"none",background:actForm.title.trim()?clientColor:"#e2e8f0",color:"#fff",cursor:actForm.title.trim()?"pointer":"not-allowed",fontSize:12,fontWeight:700}}>
              {editActId?"💾 Salvar":"✅ Adicionar"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function UnitPanel({ unit, onUpdate, onDelete, onClose, clientColor }) {
  const [tab, setTab] = useState("fat");
  const [year, setYear] = useState(today.getFullYear());
  const [actModal, setActModal] = useState(false);
  const [actForm, setActForm] = useState({title:"",desc:"",status:"pendente",prazo:"agora",data:"",horaIni:"",horaFim:""});
  const [editActId, setEditActId] = useState(null);
  const [respModal, setRespModal] = useState(false);
  const [respForm, setRespForm] = useState({nome:"",cargo:"",tel:"",email:""});
  const [editRespId, setEditRespId] = useState(null);
  const [notaModal, setNotaModal] = useState(false);
  const [notaForm, setNotaForm] = useState({respId:"",nota:5,texto:"",mes:today.getMonth(),ano:today.getFullYear()});

  const fat = unit.faturamento || {};
  const atividades = unit.atividades || [];
  const responsaveis = unit.responsaveis || [];
  const notas = unit.notas || [];

  const STATUS_CFG = {
    feito:    {bg:"#dcfce7",text:"#166534",dot:"#16a34a",label:"✅ Feito"},
    pendente: {bg:"#fef9c3",text:"#854d0e",dot:"#ca8a04",label:"🔄 Em andamento"},
    longo:    {bg:"#eff6ff",text:"#1d4ed8",dot:"#2563eb",label:"📅 Longo prazo"},
  };

  function setFat(mn,val){ onUpdate({...unit,faturamento:{...fat,[`${year}-${mn}`]:val}}); }
  function getFat(mn){ return fat[`${year}-${mn}`]||""; }
  function toNum(v){ return parseFloat((v||"").replace(/[^\d.,]/g,"").replace(",","."))||0; }

  const totalFat = MONTHS.reduce((_,__,i)=>_+toNum(fat[`${year}-${i}`]),0);
  const growth = MONTHS.map((_,i)=>{
    if(i===0||toNum(fat[`${year}-${i-1}`])===0) return null;
    return ((toNum(fat[`${year}-${i}`])-toNum(fat[`${year}-${i-1}`]))/toNum(fat[`${year}-${i-1}`])*100).toFixed(1);
  });
  const maxFat = Math.max(...MONTHS.map((_,i)=>toNum(fat[`${year}-${i}`])),1);

  function saveAct(){
    if(!actForm.title.trim()) return;
    const acts = editActId ? atividades.map(a=>a.id===editActId?{...a,...actForm}:a) : [...atividades,{...actForm,id:Date.now()}];
    onUpdate({...unit,atividades:acts});
    setActModal(false); setEditActId(null); setActForm({title:"",desc:"",status:"pendente",prazo:"agora",data:"",horaIni:"",horaFim:""});
  }
  function deleteAct(id){ onUpdate({...unit,atividades:atividades.filter(a=>a.id!==id)}); }
  function toggleAct(id){ onUpdate({...unit,atividades:atividades.map(a=>a.id===id?{...a,status:a.status==="feito"?"pendente":"feito"}:a)}); }

  function saveResp(){
    if(!respForm.nome.trim()) return;
    const list = editRespId ? responsaveis.map(r=>r.id===editRespId?{...r,...respForm}:r) : [...responsaveis,{...respForm,id:Date.now()}];
    onUpdate({...unit,responsaveis:list});
    setRespModal(false); setEditRespId(null); setRespForm({nome:"",cargo:"",tel:"",email:""});
  }
  function deleteResp(id){ onUpdate({...unit,responsaveis:responsaveis.filter(r=>r.id!==id)}); }

  function saveNota(){
    if(!notaForm.respId) return;
    const list = [...notas,{...notaForm,id:Date.now()}];
    onUpdate({...unit,notas:list});
    setNotaModal(false); setNotaForm({respId:"",nota:5,texto:"",mes:today.getMonth(),ano:today.getFullYear()});
  }
  function deleteNota(id){ onUpdate({...unit,notas:notas.filter(n=>n.id!==id)}); }

  const tabList = [{k:"fat",l:"💰 Faturamento"},{k:"ativ",l:"📋 Atividades"},{k:"resp",l:"👤 Responsáveis"},{k:"notas",l:"📝 Notas"}];

  // Activity stats for chart
  const actStats = { feito: atividades.filter(a=>a.status==="feito").length, pendente: atividades.filter(a=>a.status==="pendente").length, longo: atividades.filter(a=>a.status==="longo").length };
  const actTotal = atividades.length || 1;

  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(15,23,42,.65)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:2000,padding:12,overflowY:"auto" }}
      onClick={e=>{if(e.target===e.currentTarget)onClose();}}>
      <div style={{ background:"#fff",borderRadius:20,width:"100%",maxWidth:640,maxHeight:"95vh",display:"flex",flexDirection:"column",boxShadow:"0 24px 64px rgba(0,0,0,.35)" }}>
        {/* Header */}
        <div style={{ padding:"18px 22px",borderBottom:"1px solid #f1f5f9",display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0 }}>
          <div>
            <div style={{ fontSize:17,fontWeight:800,color:"#1e293b" }}>🏢 {unit.name}</div>
            <div style={{ fontSize:12,color:"#94a3b8",marginTop:2 }}>Unidade</div>
          </div>
          <div style={{ display:"flex",gap:8 }}>
            <button onClick={onDelete} style={{ padding:"6px 12px",borderRadius:8,border:"1px solid #fee2e2",background:"#fff",color:"#dc2626",cursor:"pointer",fontSize:12,fontWeight:600 }}>🗑️ Excluir</button>
            <button onClick={onClose} style={{ width:30,height:30,borderRadius:7,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:17,color:"#64748b",display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
          </div>
        </div>
        {/* Tabs */}
        <div style={{ display:"flex",gap:2,padding:"0 12px",borderBottom:"1px solid #f1f5f9",flexShrink:0,overflowX:"auto" }}>
          {tabList.map(t=>(
            <button key={t.k} onClick={()=>setTab(t.k)}
              style={{ padding:"10px 14px",border:"none",cursor:"pointer",fontSize:12,fontWeight:tab===t.k?700:500,whiteSpace:"nowrap",
                background:"transparent",color:tab===t.k?clientColor:"#94a3b8",borderBottom:tab===t.k?`3px solid ${clientColor}`:"3px solid transparent" }}>
              {t.l}
            </button>
          ))}
        </div>
        {/* Body */}
        <div style={{ flex:1,overflowY:"auto",padding:"18px 22px" }}>

          {/* ── FATURAMENTO ── */}
          {tab==="fat"&&(
            <div>
              {/* Resumo */}
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:18 }}>
                {[
                  {l:"Total "+year,v:totalFat>0?`R$ ${totalFat.toLocaleString("pt-BR",{minimumFractionDigits:2})}`:"—",c:"#0d9488"},
                  {l:"Média mensal",v:totalFat>0?`R$ ${(totalFat/12).toLocaleString("pt-BR",{minimumFractionDigits:2})}`:"—",c:"#2563eb"},
                  {l:"Melhor mês",v:(()=>{const vals=MONTHS.map((_,i)=>({m:MONTHS[i].slice(0,3),v:toNum(fat[`${year}-${i}`])}));const b=vals.reduce((a,x)=>x.v>a.v?x:a,{m:"—",v:0});return b.v>0?b.m:"—";})(),c:"#7c3aed"},
                ].map((s,i)=>(
                  <div key={i} style={{ background:"#f8fafc",borderRadius:12,padding:"12px 14px",border:"1px solid #e2e8f0" }}>
                    <div style={{ fontSize:10,color:"#94a3b8",fontWeight:600,textTransform:"uppercase",letterSpacing:".5px" }}>{s.l}</div>
                    <div style={{ fontSize:17,fontWeight:800,color:s.c,marginTop:4 }}>{s.v}</div>
                  </div>
                ))}
              </div>
              {/* Year nav + tabela */}
              <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10 }}>
                <span style={{ fontWeight:700,fontSize:14,color:"#1e293b" }}>Meses de {year}</span>
                <div style={{ display:"flex",gap:6 }}>
                  <button onClick={()=>setYear(y=>y-1)} style={{ padding:"3px 10px",borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer" }}>‹</button>
                  <button onClick={()=>setYear(y=>y+1)} style={{ padding:"3px 10px",borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer" }}>›</button>
                </div>
              </div>
              <div style={{ borderRadius:12,border:"1px solid #e2e8f0",overflow:"hidden" }}>
                {MONTHS.map((mn,i)=>{
                  const val=getFat(i); const num=toNum(val); const g=growth[i];
                  return (
                    <div key={i} style={{ display:"flex",alignItems:"center",gap:10,padding:"8px 14px",borderBottom:"1px solid #f8fafc",background:num>0?"#f0fdfa":"#fff" }}>
                      <div style={{ width:80,fontSize:12,fontWeight:600,color:"#374151",flexShrink:0 }}>{mn}</div>
                      <input value={val} onChange={e=>setFat(i,e.target.value)} placeholder="R$ 0,00"
                        style={{ flex:1,padding:"6px 10px",borderRadius:7,border:`1.5px solid ${num>0?"#0d9488":"#e2e8f0"}`,fontSize:12,outline:"none" }}/>
                      {g!==null&&num>0&&<div style={{ fontSize:11,fontWeight:700,color:parseFloat(g)>=0?"#16a34a":"#dc2626",minWidth:55,textAlign:"right" }}>{parseFloat(g)>=0?"▲":"▼"}{Math.abs(g)}%</div>}
                      {!(g!==null&&num>0)&&<div style={{ minWidth:55 }}/>}
                    </div>
                  );
                })}
              </div>
              {/* Gráfico barras */}
              {totalFat>0&&(
                <div style={{ marginTop:16,padding:"14px 16px",background:"#f8fafc",borderRadius:12,border:"1px solid #e2e8f0" }}>
                  <div style={{ fontSize:12,fontWeight:600,color:"#64748b",marginBottom:10 }}>📊 Evolução do Faturamento</div>
                  <div style={{ display:"flex",gap:3,alignItems:"flex-end",height:70 }}>
                    {MONTHS.map((_,i)=>{
                      const v=toNum(fat[`${year}-${i}`]); const h=Math.round((v/maxFat)*62)+4;
                      return (
                        <div key={i} style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2 }}>
                          <div style={{ width:"100%",height:h,borderRadius:"3px 3px 0 0",background:v>0?clientColor:"#e2e8f0",transition:"height .3s" }}/>
                          <span style={{ fontSize:7,color:"#94a3b8" }}>{MONTHS[i].slice(0,1)}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── ATIVIDADES ── */}
          {tab==="ativ"&&(
            <div>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
                <div>
                  <div style={{ fontWeight:700,fontSize:15,color:"#1e293b" }}>Atividades</div>
                  <div style={{ fontSize:12,color:"#94a3b8",marginTop:2 }}>{actStats.feito} de {atividades.length} concluídas</div>
                </div>
                <button onClick={()=>{ setActForm({title:"",desc:"",status:"pendente",prazo:"agora",data:"",horaIni:"",horaFim:""}); setEditActId(null); setActModal(true); }}
                  style={{ padding:"7px 14px",borderRadius:9,border:"none",background:clientColor,color:"#fff",cursor:"pointer",fontSize:12,fontWeight:700 }}>+ Adicionar</button>
              </div>
              {/* Mini gráfico pizza de atividades */}
              {atividades.length>0&&(
                <div style={{ display:"flex",gap:10,marginBottom:16,padding:"12px 16px",background:"#f8fafc",borderRadius:12,border:"1px solid #e2e8f0",alignItems:"center" }}>
                  <div style={{ display:"flex",gap:4,flex:1 }}>
                    {[{k:"feito",c:"#16a34a"},{k:"pendente",c:"#ca8a04"},{k:"longo",c:"#2563eb"}].map(({k,c})=>(
                      actStats[k]>0&&<div key={k} style={{ height:8,borderRadius:4,background:c,flex:actStats[k],transition:"flex .3s" }}/>
                    ))}
                  </div>
                  <div style={{ display:"flex",gap:10,flexShrink:0,fontSize:11 }}>
                    <span style={{ color:"#16a34a",fontWeight:700 }}>✅ {actStats.feito}</span>
                    <span style={{ color:"#ca8a04",fontWeight:700 }}>🔄 {actStats.pendente}</span>
                    <span style={{ color:"#2563eb",fontWeight:700 }}>📅 {actStats.longo}</span>
                  </div>
                </div>
              )}
              {["feito","pendente","longo"].map(st=>{
                const items=atividades.filter(a=>a.status===st); if(!items.length) return null;
                const cfg=STATUS_CFG[st];
                return (
                  <div key={st} style={{ marginBottom:16 }}>
                    <div style={{ fontSize:11,fontWeight:700,color:cfg.text,marginBottom:7,display:"flex",alignItems:"center",gap:5 }}>
                      <div style={{ width:7,height:7,borderRadius:"50%",background:cfg.dot }}/>{cfg.label} ({items.length})
                    </div>
                    <div style={{ display:"flex",flexDirection:"column",gap:7 }}>
                      {items.map(act=>(
                        <div key={act.id} style={{ background:"#fff",borderRadius:10,border:`1px solid ${act.status==="feito"?"#bbf7d0":"#e2e8f0"}`,padding:"10px 14px",display:"flex",alignItems:"flex-start",gap:10,opacity:act.status==="feito"?.8:1 }}>
                          <button onClick={()=>toggleAct(act.id)} style={{ width:22,height:22,borderRadius:5,border:`2px solid ${cfg.dot}`,background:act.status==="feito"?cfg.dot:"transparent",cursor:"pointer",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:12,marginTop:1 }}>
                            {act.status==="feito"?"✓":""}
                          </button>
                          <div style={{ flex:1 }}>
                            <div style={{ fontSize:13,fontWeight:700,color:"#1e293b",textDecoration:act.status==="feito"?"line-through":"none" }}>{act.title}</div>
                            {act.desc&&<div style={{ fontSize:11,color:"#64748b",marginTop:2 }}>{act.desc}</div>}
                            <div style={{ display:"flex",flexWrap:"wrap",gap:5,marginTop:4 }}>
                              <span style={{ fontSize:10,padding:"2px 7px",borderRadius:7,background:cfg.bg,color:cfg.text,fontWeight:600 }}>{cfg.label}</span>
                              {act.data&&<span style={{ fontSize:10,padding:"2px 7px",borderRadius:7,background:"#f1f5f9",color:"#374151" }}>📅 {act.data}</span>}
                              {act.horaIni&&<span style={{ fontSize:10,padding:"2px 7px",borderRadius:7,background:"#eff6ff",color:"#1d4ed8" }}>▶ {act.horaIni}</span>}
                              {act.horaFim&&<span style={{ fontSize:10,padding:"2px 7px",borderRadius:7,background:"#f0fdf4",color:"#166534" }}>■ {act.horaFim}</span>}
                            </div>
                          </div>
                          <div style={{ display:"flex",gap:4 }}>
                            <button onClick={()=>{ setActForm({title:act.title,desc:act.desc||"",status:act.status,prazo:act.prazo||"agora",data:act.data||"",horaIni:act.horaIni||"",horaFim:act.horaFim||""}); setEditActId(act.id); setActModal(true); }} style={{ padding:"3px 7px",borderRadius:5,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:10,color:"#64748b" }}>✏️</button>
                            <button onClick={()=>deleteAct(act.id)} style={{ padding:"3px 7px",borderRadius:5,border:"1px solid #fee2e2",background:"#fff",cursor:"pointer",fontSize:10,color:"#dc2626" }}>🗑️</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
              {atividades.length===0&&<div style={{ textAlign:"center",padding:40,color:"#94a3b8" }}>Nenhuma atividade ainda</div>}
            </div>
          )}

          {/* ── RESPONSÁVEIS ── */}
          {tab==="resp"&&(
            <div>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
                <div style={{ fontWeight:700,fontSize:15,color:"#1e293b" }}>👤 Gerentes e Responsáveis</div>
                <button onClick={()=>{ setRespForm({nome:"",cargo:"",tel:"",email:""}); setEditRespId(null); setRespModal(true); }}
                  style={{ padding:"7px 14px",borderRadius:9,border:"none",background:clientColor,color:"#fff",cursor:"pointer",fontSize:12,fontWeight:700 }}>+ Adicionar</button>
              </div>
              <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
                {responsaveis.map(r=>(
                  <div key={r.id} style={{ background:"#fff",borderRadius:12,border:"1px solid #e2e8f0",padding:"14px 16px",display:"flex",alignItems:"flex-start",gap:12 }}>
                    <div style={{ width:42,height:42,borderRadius:"50%",background:clientColor+"22",border:`2px solid ${clientColor}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:800,color:clientColor,flexShrink:0 }}>
                      {r.nome.slice(0,1).toUpperCase()}
                    </div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:14,fontWeight:700,color:"#1e293b" }}>{r.nome}</div>
                      {r.cargo&&<div style={{ fontSize:12,color:"#64748b",marginTop:2 }}>💼 {r.cargo}</div>}
                      {r.tel&&<div style={{ fontSize:12,color:"#64748b",marginTop:1 }}>📞 {r.tel}</div>}
                      {r.email&&<div style={{ fontSize:12,color:"#64748b",marginTop:1 }}>✉️ {r.email}</div>}
                      {/* Notas deste responsável */}
                      {notas.filter(n=>n.respId===r.id).length>0&&(
                        <div style={{ marginTop:8,display:"flex",flexWrap:"wrap",gap:6 }}>
                          {notas.filter(n=>n.respId===r.id).slice(-3).map(n=>(
                            <div key={n.id} style={{ fontSize:10,padding:"3px 8px",borderRadius:8,background:"#fef9c3",border:"1px solid #fde68a",color:"#92400e" }}>
                              {MONTHS[n.mes].slice(0,3)}/{n.ano} — {NOTA_LABELS[n.nota]}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div style={{ display:"flex",gap:5,flexDirection:"column" }}>
                      <button onClick={()=>{ setNotaForm({respId:r.id,nota:5,texto:"",mes:today.getMonth(),ano:today.getFullYear()}); setNotaModal(true); }}
                        style={{ padding:"4px 8px",borderRadius:6,border:`1px solid ${clientColor}44`,background:clientColor+"11",cursor:"pointer",fontSize:10,color:clientColor,fontWeight:700 }}>+ Nota</button>
                      <button onClick={()=>{ setRespForm({nome:r.nome,cargo:r.cargo||"",tel:r.tel||"",email:r.email||""}); setEditRespId(r.id); setRespModal(true); }}
                        style={{ padding:"4px 8px",borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:10,color:"#64748b" }}>✏️</button>
                      <button onClick={()=>deleteResp(r.id)} style={{ padding:"4px 8px",borderRadius:6,border:"1px solid #fee2e2",background:"#fff",cursor:"pointer",fontSize:10,color:"#dc2626" }}>🗑️</button>
                    </div>
                  </div>
                ))}
                {responsaveis.length===0&&<div style={{ textAlign:"center",padding:40,color:"#94a3b8" }}>Nenhum responsável cadastrado</div>}
              </div>
            </div>
          )}

          {/* ── NOTAS ── */}
          {tab==="notas"&&(
            <div>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
                <div style={{ fontWeight:700,fontSize:15,color:"#1e293b" }}>📝 Notas de Avaliação</div>
                {responsaveis.length>0&&(
                  <button onClick={()=>{ setNotaForm({respId:"",nota:5,texto:"",mes:today.getMonth(),ano:today.getFullYear()}); setNotaModal(true); }}
                    style={{ padding:"7px 14px",borderRadius:9,border:"none",background:clientColor,color:"#fff",cursor:"pointer",fontSize:12,fontWeight:700 }}>+ Nova Nota</button>
                )}
              </div>
              {responsaveis.length===0&&<div style={{ textAlign:"center",padding:30,color:"#94a3b8",fontSize:13 }}>Cadastre responsáveis primeiro para adicionar notas</div>}
              {/* Gráfico evolução de notas por responsável */}
              {responsaveis.length>0&&notas.length>0&&(
                <div style={{ marginBottom:18,padding:"14px 16px",background:"#f8fafc",borderRadius:12,border:"1px solid #e2e8f0" }}>
                  <div style={{ fontSize:12,fontWeight:600,color:"#64748b",marginBottom:10 }}>📊 Evolução das Avaliações</div>
                  {responsaveis.map(r=>{
                    const rNotas = notas.filter(n=>n.respId===r.id).sort((a,b)=>a.ano*12+a.mes-(b.ano*12+b.mes));
                    if(!rNotas.length) return null;
                    const avg = (rNotas.reduce((s,n)=>s+n.nota,0)/rNotas.length).toFixed(1);
                    return (
                      <div key={r.id} style={{ marginBottom:12 }}>
                        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5 }}>
                          <span style={{ fontSize:12,fontWeight:600,color:"#374151" }}>{r.nome}</span>
                          <span style={{ fontSize:12,color:clientColor,fontWeight:700 }}>Média: {avg}/5 {NOTA_LABELS[Math.round(parseFloat(avg))]}</span>
                        </div>
                        <div style={{ display:"flex",gap:4,alignItems:"flex-end",height:36 }}>
                          {rNotas.slice(-12).map((n,i)=>(
                            <div key={i} style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:1 }}>
                              <div style={{ width:"100%",borderRadius:"3px 3px 0 0",background:clientColor,height:Math.round((n.nota/5)*30)+2,transition:"height .3s" }}/>
                              <span style={{ fontSize:7,color:"#94a3b8" }}>{MONTHS[n.mes].slice(0,1)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
              <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
                {notas.slice().reverse().map(n=>{
                  const resp = responsaveis.find(r=>r.id===n.respId);
                  return (
                    <div key={n.id} style={{ background:"#fff",borderRadius:12,border:"1px solid #e2e8f0",padding:"12px 16px",display:"flex",alignItems:"flex-start",gap:12 }}>
                      <div style={{ width:36,height:36,borderRadius:"50%",background:clientColor+"22",border:`2px solid ${clientColor}44`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:800,color:clientColor,flexShrink:0 }}>
                        {resp?.nome.slice(0,1)||"?"}
                      </div>
                      <div style={{ flex:1 }}>
                        <div style={{ display:"flex",alignItems:"center",gap:8,flexWrap:"wrap" }}>
                          <span style={{ fontSize:13,fontWeight:700,color:"#1e293b" }}>{resp?.nome||"?"}</span>
                          <span style={{ fontSize:12,color:"#f59e0b" }}>{NOTA_LABELS[n.nota]}</span>
                          <span style={{ fontSize:11,color:"#94a3b8" }}>{MONTHS[n.mes]} {n.ano}</span>
                        </div>
                        {n.texto&&<div style={{ fontSize:12,color:"#64748b",marginTop:4,fontStyle:"italic" }}>"{n.texto}"</div>}
                      </div>
                      <button onClick={()=>deleteNota(n.id)} style={{ padding:"3px 7px",borderRadius:5,border:"1px solid #fee2e2",background:"#fff",cursor:"pointer",fontSize:10,color:"#dc2626" }}>🗑️</button>
                    </div>
                  );
                })}
                {notas.length===0&&<div style={{ textAlign:"center",padding:40,color:"#94a3b8" }}>Nenhuma nota cadastrada</div>}
              </div>
            </div>
          )}
        </div>
      </div>

      {actModal&&<ActModal actForm={actForm} setActForm={setActForm} editActId={editActId} setEditActId={setEditActId} setActModal={setActModal} clientColor={clientColor} saveAct={saveAct}/>}

            {/* Modal responsável */}
      {respModal&&(
        <div style={{ position:"fixed",inset:0,background:"rgba(15,23,42,.7)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:3000,padding:16 }}
          onClick={e=>{if(e.target===e.currentTarget)setRespModal(false);}}>
          <div style={{ background:"#fff",borderRadius:18,padding:24,width:"100%",maxWidth:400,boxShadow:"0 20px 60px rgba(0,0,0,.3)" }}>
            <div style={{ display:"flex",justifyContent:"space-between",marginBottom:16 }}>
              <div style={{ fontSize:16,fontWeight:800,color:"#1e293b" }}>{editRespId?"✏️ Editar":"➕ Novo"} Responsável</div>
              <button onClick={()=>setRespModal(false)} style={{ width:28,height:28,borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:16,color:"#64748b",display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
            </div>
            <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
              {[["nome","Nome completo *","text"],["cargo","Cargo / Função","text"],["tel","Telefone","tel"],["email","E-mail","email"]].map(([k,ph,t])=>(
                <input key={k} type={t} value={respForm[k]} onChange={e=>setRespForm(f=>({...f,[k]:e.target.value}))} placeholder={ph}
                  style={{ padding:"8px 12px",borderRadius:8,border:`1.5px solid ${k==="nome"&&respForm.nome?"#0d9488":"#e2e8f0"}`,fontSize:13,outline:"none" }}/>
              ))}
              <div style={{ display:"flex",gap:7,marginTop:4 }}>
                <button onClick={()=>setRespModal(false)} style={{ flex:1,padding:"9px 0",borderRadius:8,border:"1.5px solid #e2e8f0",background:"#f8fafc",color:"#64748b",cursor:"pointer",fontSize:12,fontWeight:600 }}>Cancelar</button>
                <button onClick={saveResp} disabled={!respForm.nome.trim()} style={{ flex:2,padding:"9px 0",borderRadius:8,border:"none",background:respForm.nome.trim()?clientColor:"#e2e8f0",color:"#fff",cursor:respForm.nome.trim()?"pointer":"not-allowed",fontSize:12,fontWeight:700 }}>
                  {editRespId?"💾 Salvar":"✅ Adicionar"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal nota */}
      {notaModal&&(
        <div style={{ position:"fixed",inset:0,background:"rgba(15,23,42,.7)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:3000,padding:16 }}
          onClick={e=>{if(e.target===e.currentTarget)setNotaModal(false);}}>
          <div style={{ background:"#fff",borderRadius:18,padding:24,width:"100%",maxWidth:400,boxShadow:"0 20px 60px rgba(0,0,0,.3)" }}>
            <div style={{ display:"flex",justifyContent:"space-between",marginBottom:16 }}>
              <div style={{ fontSize:16,fontWeight:800,color:"#1e293b" }}>📝 Nova Nota</div>
              <button onClick={()=>setNotaModal(false)} style={{ width:28,height:28,borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:16,color:"#64748b",display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
            </div>
            <div style={{ display:"flex",flexDirection:"column",gap:11 }}>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>Responsável *</label>
                <select value={notaForm.respId} onChange={e=>setNotaForm(f=>({...f,respId:e.target.value}))}
                  style={{ width:"100%",padding:"8px 12px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none" }}>
                  <option value="">Selecione...</option>
                  {responsaveis.map(r=><option key={r.id} value={r.id}>{r.nome}{r.cargo?` — ${r.cargo}`:""}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>Mês/Ano</label>
                <div style={{ display:"flex",gap:8 }}>
                  <select value={notaForm.mes} onChange={e=>setNotaForm(f=>({...f,mes:parseInt(e.target.value)}))}
                    style={{ flex:2,padding:"8px 10px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none" }}>
                    {MONTHS.map((m,i)=><option key={i} value={i}>{m}</option>)}
                  </select>
                  <input type="number" value={notaForm.ano} onChange={e=>setNotaForm(f=>({...f,ano:parseInt(e.target.value)||today.getFullYear()}))}
                    style={{ flex:1,padding:"8px 10px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none" }}/>
                </div>
              </div>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:8,textTransform:"uppercase",letterSpacing:".5px" }}>Avaliação</label>
                <div style={{ display:"flex",gap:6 }}>
                  {[1,2,3,4,5].map(n=>(
                    <button key={n} onClick={()=>setNotaForm(f=>({...f,nota:n}))}
                      style={{ flex:1,padding:"8px 0",borderRadius:8,border:`2px solid ${notaForm.nota>=n?"#f59e0b":"#e2e8f0"}`,background:notaForm.nota>=n?"#fef9c3":"#f8fafc",cursor:"pointer",fontSize:18 }}>
                      ⭐
                    </button>
                  ))}
                </div>
                <div style={{ textAlign:"center",fontSize:12,color:"#92400e",marginTop:5,fontWeight:600 }}>{notaForm.nota}/5 estrelas</div>
              </div>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>Observação</label>
                <textarea value={notaForm.texto} onChange={e=>setNotaForm(f=>({...f,texto:e.target.value}))} placeholder="Comentários sobre o desempenho..." rows={3}
                  style={{ width:"100%",padding:"8px 12px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",resize:"vertical",boxSizing:"border-box",fontFamily:"inherit" }}/>
              </div>
              <div style={{ display:"flex",gap:7,marginTop:4 }}>
                <button onClick={()=>setNotaModal(false)} style={{ flex:1,padding:"9px 0",borderRadius:8,border:"1.5px solid #e2e8f0",background:"#f8fafc",color:"#64748b",cursor:"pointer",fontSize:12,fontWeight:600 }}>Cancelar</button>
                <button onClick={saveNota} disabled={!notaForm.respId} style={{ flex:2,padding:"9px 0",borderRadius:8,border:"none",background:notaForm.respId?clientColor:"#e2e8f0",color:"#fff",cursor:notaForm.respId?"pointer":"not-allowed",fontSize:12,fontWeight:700 }}>
                  💾 Salvar Nota
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── GESTOR DE UNIDADES (usado dentro do ClientPanel e AdminPanel) ──────────
function UnidadesSection({ clientId, clientColor, clientData, setClientData }) {
  const [showUnit, setShowUnit] = useState(null);
  const [addingUnit, setAddingUnit] = useState(false);
  const [newUnitName, setNewUnitName] = useState("");

  const myData = clientData[clientId] || { faturamento:{}, atividades:[], unidades:[] };
  const unidades = myData.unidades || [];

  function setMyData(fn){ setClientData(p=>({...p,[clientId]:fn(p[clientId]||{faturamento:{},atividades:[],unidades:[]})})); }

  function addUnit(){
    if(!newUnitName.trim()) return;
    setMyData(d=>({...d,unidades:[...(d.unidades||[]),{id:Date.now(),name:newUnitName.trim(),faturamento:{},atividades:[],responsaveis:[],notas:[]}]}));
    setNewUnitName(""); setAddingUnit(false);
  }

  function updateUnit(id,updated){ setMyData(d=>({...d,unidades:(d.unidades||[]).map(u=>u.id===id?updated:u)})); }
  function deleteUnit(id){ setMyData(d=>({...d,unidades:(d.unidades||[]).filter(u=>u.id!==id)})); }

  return (
    <div>
      <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
        <div>
          <div style={{ fontWeight:700,fontSize:15,color:"#1e293b" }}>🏢 Unidades</div>
          <div style={{ fontSize:12,color:"#94a3b8",marginTop:2 }}>{unidades.length} unidade{unidades.length!==1?"s":""} cadastrada{unidades.length!==1?"s":""}</div>
        </div>
        <button onClick={()=>setAddingUnit(true)}
          style={{ padding:"7px 14px",borderRadius:9,border:"none",background:clientColor,color:"#fff",cursor:"pointer",fontSize:12,fontWeight:700 }}>
          + Nova Unidade
        </button>
      </div>

      {addingUnit&&(
        <div style={{ display:"flex",gap:8,marginBottom:14,padding:"12px 14px",background:"#f0fdfa",borderRadius:10,border:`1.5px solid ${clientColor}44` }}>
          <input value={newUnitName} onChange={e=>setNewUnitName(e.target.value)} placeholder="Nome da unidade (ex: Filial Centro, Loja Norte...)"
            onKeyDown={e=>e.key==="Enter"&&addUnit()}
            autoFocus
            style={{ flex:1,padding:"8px 12px",borderRadius:8,border:`1.5px solid ${clientColor}`,fontSize:13,outline:"none" }}/>
          <button onClick={addUnit} style={{ padding:"8px 14px",borderRadius:8,border:"none",background:clientColor,color:"#fff",cursor:"pointer",fontSize:13,fontWeight:700 }}>✓</button>
          <button onClick={()=>{setAddingUnit(false);setNewUnitName("");}} style={{ padding:"8px 12px",borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:13,color:"#64748b" }}>✕</button>
        </div>
      )}

      {unidades.length===0&&!addingUnit&&(
        <div style={{ textAlign:"center",padding:"40px 20px",color:"#94a3b8",background:"#f8fafc",borderRadius:12,border:"1px dashed #e2e8f0" }}>
          <div style={{ fontSize:36,marginBottom:8 }}>🏢</div>
          <div style={{ fontSize:14,fontWeight:500 }}>Nenhuma unidade cadastrada</div>
          <div style={{ fontSize:12,marginTop:4 }}>Clique em "+ Nova Unidade" para adicionar</div>
        </div>
      )}

      <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:10 }}>
        {unidades.map(u=>{
          const fatTotal = MONTHS.reduce((_,__,i)=>_+(parseFloat((u.faturamento[`${today.getFullYear()}-${i}`]||"").replace(/[^\d.,]/g,"").replace(",","."))||0),0);
          const actFeitas = (u.atividades||[]).filter(a=>a.status==="feito").length;
          const actTotal = (u.atividades||[]).length;
          return (
            <div key={u.id} onClick={()=>setShowUnit(u.id)}
              style={{ background:"#fff",borderRadius:14,border:`1.5px solid ${clientColor}22`,padding:"16px",cursor:"pointer",
                boxShadow:"0 1px 4px rgba(0,0,0,.06)",transition:"all .15s",position:"relative",overflow:"hidden" }}>
              <div style={{ position:"absolute",top:0,left:0,width:4,height:"100%",background:clientColor,borderRadius:"4px 0 0 4px" }}/>
              <div style={{ paddingLeft:8 }}>
                <div style={{ fontSize:14,fontWeight:700,color:"#1e293b",marginBottom:8 }}>{u.name}</div>
                <div style={{ display:"flex",flexDirection:"column",gap:4 }}>
                  {fatTotal>0&&(
                    <div style={{ fontSize:11,color:"#0d9488",fontWeight:600 }}>
                      💰 R$ {fatTotal.toLocaleString("pt-BR",{minimumFractionDigits:0,maximumFractionDigits:0})}
                    </div>
                  )}
                  {actTotal>0&&(
                    <div style={{ fontSize:11,color:"#64748b" }}>
                      ✅ {actFeitas}/{actTotal} atividades
                    </div>
                  )}
                  {(u.responsaveis||[]).length>0&&(
                    <div style={{ fontSize:11,color:"#64748b" }}>
                      👤 {(u.responsaveis||[]).length} responsável(is)
                    </div>
                  )}
                </div>
                <div style={{ marginTop:10,fontSize:10,color:clientColor,fontWeight:600 }}>Abrir detalhes →</div>
              </div>
            </div>
          );
        })}
      </div>

      {showUnit&&(()=>{
        const unit = unidades.find(u=>u.id===showUnit);
        if(!unit) return null;
        return <UnitPanel unit={unit} clientColor={clientColor}
          onUpdate={updated=>updateUnit(showUnit,updated)}
          onDelete={()=>{ deleteUnit(showUnit); setShowUnit(null); }}
          onClose={()=>setShowUnit(null)}/>;
      })()}
    </div>
  );
}

// ── PAINEL CLIENTE ────────────────────────────────────────────────────────
function ClientPanel({ userId, users, setUsers, events, setEvents, onLogout, clientData, setClientData }) {
  const person = users[userId];
  const [view, setView] = useState("agenda");
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [selectedDay, setSelectedDay] = useState(null);
  const [modal, setModal] = useState(false);
  const [editingEventId, setEditingEventId] = useState(null);
  const [form, setForm] = useState({title:"",description:"",time:"",priority:"media",category:""});
  const [showProfile, setShowProfile] = useState(false);
  const [actModal, setActModal] = useState(false);
  const [actForm, setActForm] = useState({title:"",desc:"",status:"pendente",prazo:"agora",data:"",horaIni:"",horaFim:""});
  const [editActId, setEditActId] = useState(null);

  const daysInMonth=getDaysInMonth(year,month);
  const firstDay=getFirstDay(year,month);
  const myData = clientData[userId] || { faturamento:{}, atividades:[] };

  function setMyData(fn){ setClientData(p=>({...p,[userId]:fn(p[userId]||{faturamento:{},atividades:[]})})); }

  // Faturamento
  function setFat(yr,mn,val){
    setMyData(d=>({...d,faturamento:{...d.faturamento,[`${yr}-${mn}`]:val}}));
  }
  function getFat(yr,mn){ return myData.faturamento[`${yr}-${mn}`]||""; }

  // Crescimento
  function calcGrowth(){
    const vals = MONTHS.map((_,i)=>parseFloat((myData.faturamento[`${year}-${i}`]||"").replace(/[^\d.,]/g,"").replace(",","."))||0);
    const results = vals.map((v,i)=>{
      if(i===0||vals[i-1]===0) return null;
      return ((v - vals[i-1]) / vals[i-1] * 100).toFixed(1);
    });
    return results;
  }
  const growth = calcGrowth();
  const totalFat = MONTHS.reduce((_,__,i)=>_+(parseFloat((myData.faturamento[`${year}-${i}`]||"").replace(/[^\d.,]/g,"").replace(",","."))||0),0);

  // Atividades
  function saveAct(){
    if(!actForm.title.trim()) return;
    setMyData(d=>{
      const acts = d.atividades||[];
      if(editActId){ return {...d,atividades:acts.map(a=>a.id===editActId?{...a,...actForm}:a)}; }
      return {...d,atividades:[...acts,{...actForm,id:Date.now()}]};
    });
    setActModal(false); setEditActId(null); setActForm({title:"",desc:"",status:"pendente",prazo:"agora",data:"",horaIni:"",horaFim:""});
  }
  function deleteAct(id){ setMyData(d=>({...d,atividades:(d.atividades||[]).filter(a=>a.id!==id)})); }
  function toggleAct(id){
    setMyData(d=>({...d,atividades:(d.atividades||[]).map(a=>a.id===id?{...a,status:a.status==="feito"?"pendente":"feito"}:a)}));
  }

  // Agenda
  function getEventsDay(day){ return events[`${userId}::${fmtKey(year,month,day)}`]||[]; }
  function openAdd(day){ setSelectedDay(day); setEditingEventId(null); setForm({title:"",description:"",time:"",priority:"media",category:""}); setModal(true); }
  function openEdit(day,ev){ if(ev.fromAdmin)return; setSelectedDay(day); setEditingEventId(ev.id); setForm({title:ev.title,description:ev.description||"",time:ev.time||"",priority:ev.priority||"media",category:ev.category||""}); setModal(true); }
  function saveEvent(){ if(!form.title.trim())return; const key=`${userId}::${fmtKey(year,month,selectedDay)}`; const ex=events[key]||[]; if(editingEventId){setEvents(p=>({...p,[key]:ex.map(e=>e.id===editingEventId?{...e,...form}:e)}))}else{setEvents(p=>({...p,[key]:[...ex,{...form,id:Date.now()}]}))} setModal(false); }
  function delEvent(day,id){ const key=`${userId}::${fmtKey(year,month,day)}`; setEvents(p=>({...p,[key]:(p[key]||[]).filter(e=>e.id!==id)})); setModal(false); }
  function getAllEventsMonth(){ const r=[]; for(let d=1;d<=daysInMonth;d++){ const key=`${userId}::${fmtKey(year,month,d)}`; (events[key]||[]).forEach(ev=>r.push({day:d,ev})); } return r.sort((a,b)=>a.day-b.day||(a.ev.time||"").localeCompare(b.ev.time||"")); }
  function prevMonth(){ if(month===0){setMonth(11);setYear(y=>y-1);}else setMonth(m=>m-1); }
  function nextMonth(){ if(month===11){setMonth(0);setYear(y=>y+1);}else setMonth(m=>m+1); }

  const allMonthEvents=getAllEventsMonth();
  const adminCount=allMonthEvents.filter(x=>x.ev.fromAdmin).length;
  const atividades = myData.atividades||[];
  const STATUS_CFG = {
    feito:    {bg:"#dcfce7",text:"#166534",dot:"#16a34a",label:"✅ Feito"},
    pendente: {bg:"#fef9c3",text:"#854d0e",dot:"#ca8a04",label:"🔄 Em andamento"},
    longo:    {bg:"#eff6ff",text:"#1d4ed8",dot:"#2563eb",label:"📅 Longo prazo"},
  };

  function saveProfile({photo,status,name}){
    setUsers(p=>({...p,[userId]:{...p[userId],photo,status,name}}));
    setShowProfile(false);
  }

  const views = ["agenda","faturamento","atividades","unidades"];
  const viewLabels = {agenda:"📅 Agenda",faturamento:"💰 Faturamento",atividades:"📋 Atividades",unidades:"🏢 Unidades"};

  return (
    <div style={{ fontFamily:"'Inter','Segoe UI',sans-serif",minHeight:"100vh",background:"#f8fafc" }}>
      {/* HEADER */}
      <div style={{ background:"#000",padding:"0 20px",boxShadow:"0 2px 8px rgba(0,0,0,.6)" }}>
        <div style={{ maxWidth:1000,margin:"0 auto" }}>
          <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between", paddingTop:14, paddingBottom:14,flexWrap:"wrap",gap:10 }}>
            <div style={{ display:"flex",alignItems:"center",gap:12 }}>
              <Avatar user={person} size={40} onClick={()=>setShowProfile(true)}/>
              <div>
                <GrupoGomesLogo height={36}/>
                <p style={{ color:person.color,fontSize:11,margin:"3px 0 0",fontWeight:600 }}>{person.name}</p>
              </div>
            </div>
            <div style={{ display:"flex",gap:6,flexWrap:"wrap" }}>
              {views.map(v=>(
                <button key={v} onClick={()=>setView(v)}
                  style={{ padding:"6px 12px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,
                    background:view===v?"#0d9488":"#111",color:view===v?"#fff":"#94a3b8" }}>
                  {viewLabels[v]}
                </button>
              ))}
              <button onClick={()=>setShowProfile(true)} style={{ padding:"6px 12px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:"#111",color:"#94a3b8" }}>✏️ Perfil</button>
              <button onClick={onLogout} style={{ padding:"6px 12px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:"#111",color:"#f87171" }}>🚪 Sair</button>
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth:1000,margin:"0 auto",padding:"20px 16px" }}>
        <ProfileCard user={person} onEdit={()=>setShowProfile(true)}/>

        {/* ── AGENDA ── */}
        {view==="agenda" && (
          <div>
            {adminCount>0&&(
              <div style={{ marginBottom:14,padding:"10px 16px",background:"#eff6ff",borderRadius:10,border:"1px solid #bfdbfe",fontSize:12,color:"#1d4ed8",display:"flex",alignItems:"center",gap:8 }}>
                📌 <strong>{adminCount} compromisso{adminCount>1?"s":""}</strong> {adminCount>1?"foram enviados":"foi enviado"} pela consultoria para sua agenda neste mês.
              </div>
            )}
            <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16,flexWrap:"wrap",gap:10 }}>
              <div style={{ fontSize:13,color:"#94a3b8" }}>{allMonthEvents.length} evento{allMonthEvents.length!==1?"s":""} em {MONTHS[month]}</div>
              <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                <button onClick={prevMonth} style={{ width:34,height:34,borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center" }}>‹</button>
                <span style={{ fontWeight:700,fontSize:15,color:"#1e293b",minWidth:150,textAlign:"center" }}>{MONTHS[month]} {year}</span>
                <button onClick={nextMonth} style={{ width:34,height:34,borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center" }}>›</button>
                <button onClick={()=>{setMonth(today.getMonth());setYear(today.getFullYear());}} style={{ padding:"6px 12px",borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:12,color:"#64748b" }}>Hoje</button>
              </div>
            </div>
            <CalendarGrid person={person} year={year} month={month} getEventsDay={getEventsDay} daysInMonth={daysInMonth} firstDay={firstDay} onAddDay={openAdd} onEditEvent={openEdit}/>
          </div>
        )}

        {/* ── FATURAMENTO ── */}
        {view==="faturamento" && (
          <div>
            {/* Resumo */}
            <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:20 }}>
              <div style={{ background:"#fff",borderRadius:14,padding:"16px 18px",border:"1px solid #e2e8f0",boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
                <div style={{ fontSize:11,color:"#94a3b8",fontWeight:600,textTransform:"uppercase",letterSpacing:".5px" }}>Total {year}</div>
                <div style={{ fontSize:22, fontWeight:800,color:"#0d9488",marginTop:4 }}>
                  {totalFat > 0 ? `R$ ${totalFat.toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2})}` : "—"}
                </div>
              </div>
              <div style={{ background:"#fff",borderRadius:14,padding:"16px 18px",border:"1px solid #e2e8f0",boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
                <div style={{ fontSize:11,color:"#94a3b8",fontWeight:600,textTransform:"uppercase",letterSpacing:".5px" }}>Média Mensal</div>
                <div style={{ fontSize:22, fontWeight:800,color:"#2563eb",marginTop:4 }}>
                  {totalFat > 0 ? `R$ ${(totalFat/12).toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2})}` : "—"}
                </div>
              </div>
              <div style={{ background:"#fff",borderRadius:14,padding:"16px 18px",border:"1px solid #e2e8f0",boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
                <div style={{ fontSize:11,color:"#94a3b8",fontWeight:600,textTransform:"uppercase",letterSpacing:".5px" }}>Melhor Mês</div>
                <div style={{ fontSize:22, fontWeight:800,color:"#7c3aed",marginTop:4 }}>
                  {(()=>{
                    const vals = MONTHS.map((_,i)=>({m:MONTHS[i],v:parseFloat((myData.faturamento[`${year}-${i}`]||"").replace(/[^\d.,]/g,"").replace(",","."))||0}));
                    const best = vals.reduce((a,b)=>b.v>a.v?b:a,{m:"—",v:0});
                    return best.v>0 ? best.m : "—";
                  })()}
                </div>
              </div>
            </div>

            {/* Tabela dos 12 meses */}
            <div style={{ background:"#fff",borderRadius:16,border:"1px solid #e2e8f0",overflow:"hidden",boxShadow:"0 1px 4px rgba(0,0,0,.06)" }}>
              <div style={{ padding:"16px 20px", borderBottom:"1px solid #f1f5f9",display:"flex",alignItems:"center",justifyContent:"space-between" }}>
                <div style={{ fontWeight:700,fontSize:15,color:"#1e293b" }}>💰 Faturamento Mensal</div>
                <div style={{ display:"flex",gap:8 }}>
                  <button onClick={()=>setYear(y=>y-1)} style={{ padding:"4px 10px",borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:13 }}>‹</button>
                  <span style={{ fontWeight:700,color:"#1e293b",fontSize:14,padding:"4px 8px" }}>{year}</span>
                  <button onClick={()=>setYear(y=>y+1)} style={{ padding:"4px 10px",borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:13 }}>›</button>
                </div>
              </div>
              <div style={{ padding:"8px 0" }}>
                {MONTHS.map((mn,i)=>{
                  const val = getFat(year,i);
                  const g = growth[i];
                  const numVal = parseFloat((val||"").replace(/[^\d.,]/g,"").replace(",","."))||0;
                  return (
                    <div key={i} style={{ display:"flex",alignItems:"center",gap:12,padding:"10px 20px", borderBottom:"1px solid #f8fafc" }}>
                      <div style={{ width:90,fontSize:13,fontWeight:600,color:"#374151",flexShrink:0 }}>{mn}</div>
                      <input
                        value={val}
                        onChange={e=>setFat(year,i,e.target.value)}
                        placeholder="R$ 0,00"
                        style={{ flex:1,padding:"7px 12px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",
                          borderColor: numVal>0?"#0d9488":"#e2e8f0",background: numVal>0?"#f0fdfa":"#fff" }}
                      />
                      {g!==null && numVal>0 && (
                        <div style={{ fontSize:12,fontWeight:700,color:parseFloat(g)>=0?"#16a34a":"#dc2626",flexShrink:0,minWidth:60, textAlign:"right" }}>
                          {parseFloat(g)>=0?"▲":"▼"} {Math.abs(g)}%
                        </div>
                      )}
                      {(g===null || numVal===0) && <div style={{ minWidth:60 }}/>}
                    </div>
                  );
                })}
              </div>
              {/* Barra de crescimento visual */}
              {totalFat > 0 && (
                <div style={{ padding:"16px 20px", borderTop:"1px solid #f1f5f9" }}>
                  <div style={{ fontSize:12,fontWeight:600,color:"#64748b",marginBottom:8 }}>Crescimento mensal</div>
                  <div style={{ display:"flex",gap:4,alignItems:"flex-end",height:60 }}>
                    {MONTHS.map((_,i)=>{
                      const v = parseFloat((myData.faturamento[`${year}-${i}`]||"").replace(/[^\d.,]/g,"").replace(",","."))||0;
                      const maxV = Math.max(...MONTHS.map((__,j)=>parseFloat((myData.faturamento[`${year}-${j}`]||"").replace(/[^\d.,]/g,"").replace(",","."))||0));
                      const h = maxV>0 ? Math.round((v/maxV)*52)+8 : 8;
                      return (
                        <div key={i} style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2 }}>
                          <div style={{ width:"100%",height:h,borderRadius:"4px 4px 0 0",background: v>0?"#0d9488":"#e2e8f0",transition:"height .3s" }}/>
                          <span style={{ fontSize:8,color:"#94a3b8" }}>{MONTHS[i].slice(0,3)}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── ATIVIDADES ── */}
        {view==="atividades" && (
          <div>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16 }}>
              <div>
                <h3 style={{ margin:0,fontSize:16,fontWeight:700,color:"#1e293b" }}>📋 Atividades de Consultoria</h3>
                <p style={{ margin:"4px 0 0",fontSize:12,color:"#94a3b8" }}>{atividades.filter(a=>a.status==="feito").length} de {atividades.length} concluídas</p>
              </div>
              <button onClick={()=>{ setActForm({title:"",desc:"",status:"pendente",prazo:"agora",data:"",horaIni:"",horaFim:""}); setEditActId(null); setActModal(true); }}
                style={{ padding:"8px 16px",borderRadius:10,border:"none",background:"#0d9488",color:"#fff",cursor:"pointer",fontSize:13,fontWeight:700 }}>
                + Nova Atividade
              </button>
            </div>

            {/* Filtros por status */}
            {["feito","pendente","longo"].map(st=>{
              const items = atividades.filter(a=>a.status===st);
              if(!items.length) return null;
              const cfg = STATUS_CFG[st];
              return (
                <div key={st} style={{ marginBottom:20 }}>
                  <div style={{ fontSize:12,fontWeight:700,color:cfg.text,marginBottom:8,display:"flex",alignItems:"center",gap:6 }}>
                    <div style={{ width:8,height:8,borderRadius:"50%",background:cfg.dot }}/>
                    {cfg.label} ({items.length})
                  </div>
                  <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
                    {items.map(act=>(
                      <div key={act.id} style={{ background:"#fff",borderRadius:12,border:`1px solid ${act.status==="feito"?"#bbf7d0":"#e2e8f0"}`,
                        padding:"12px 16px",display:"flex",alignItems:"flex-start",gap:12,
                        opacity: act.status==="feito" ? 0.8 : 1 }}>
                        <button onClick={()=>toggleAct(act.id)}
                          style={{ width:24,height:24,borderRadius:6,border:`2px solid ${cfg.dot}`,
                            background: act.status==="feito" ? cfg.dot : "transparent",
                            cursor:"pointer",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:13,marginTop:1 }}>
                          {act.status==="feito" ? "✓" : ""}
                        </button>
                        <div style={{ flex:1 }}>
                          <div style={{ fontSize:14,fontWeight:700,color:"#1e293b", textDecoration:act.status==="feito"?"line-through":"none" }}>{act.title}</div>
                          {act.desc && <div style={{ fontSize:12,color:"#64748b",marginTop:3 }}>{act.desc}</div>}
                          <div style={{ display:"flex",flexWrap:"wrap",gap:5,marginTop:5 }}>
                            <span style={{ fontSize:10,padding:"2px 8px",borderRadius:8,background:cfg.bg,color:cfg.text,fontWeight:600 }}>{cfg.label}</span>
                            <span style={{ fontSize:10,padding:"2px 8px",borderRadius:8,background:"#f1f5f9",color:"#64748b" }}>
                              {act.prazo==="agora"?"⏰ Agora":"🔭 Longo prazo"}
                            </span>
                            {act.data&&<span style={{ fontSize:10,padding:"2px 8px",borderRadius:8,background:"#f1f5f9",color:"#374151" }}>📅 {act.data}</span>}
                            {act.horaIni&&<span style={{ fontSize:10,padding:"2px 8px",borderRadius:8,background:"#eff6ff",color:"#1d4ed8" }}>▶ {act.horaIni}</span>}
                            {act.horaFim&&<span style={{ fontSize:10,padding:"2px 8px",borderRadius:8,background:"#f0fdf4",color:"#166534" }}>■ {act.horaFim}</span>}
                          </div>
                        </div>
                        <div style={{ display:"flex",gap:5 }}>
                          <button onClick={()=>{ setActForm({title:act.title,desc:act.desc||"",status:act.status,prazo:act.prazo||"agora",data:act.data||"",horaIni:act.horaIni||"",horaFim:act.horaFim||""}); setEditActId(act.id); setActModal(true); }}
                            style={{ padding:"4px 8px",borderRadius:6,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:11,color:"#64748b" }}>✏️</button>
                          <button onClick={()=>deleteAct(act.id)}
                            style={{ padding:"4px 8px",borderRadius:6,border:"1px solid #fee2e2",background:"#fff",cursor:"pointer",fontSize:11,color:"#dc2626" }}>🗑️</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}

            {atividades.length===0 && (
              <div style={{ background:"#fff",borderRadius:16,border:"1px solid #e2e8f0",padding:60, textAlign:"center" }}>
                <div style={{ fontSize:44,marginBottom:10 }}>📋</div>
                <div style={{ color:"#94a3b8",fontSize:14 }}>Nenhuma atividade cadastrada</div>
                <div style={{ color:"#cbd5e1",fontSize:12,marginTop:4 }}>Clique em "+ Nova Atividade" para começar</div>
              </div>
            )}
          </div>
        )}

        {/* ── UNIDADES ── */}
        {view==="unidades"&&(
          <UnidadesSection clientId={userId} clientColor={person.color} clientData={clientData} setClientData={setClientData}/>
        )}
      </div>

      {/* Modal tarefa agenda */}
      {modal&&<TaskModal person={person} selectedDay={selectedDay} month={month} year={year} editingEvent={editingEventId} form={form} setForm={setForm} onSave={saveEvent} onDelete={()=>delEvent(selectedDay,editingEventId)} onClose={()=>setModal(false)} users={users} isAdmin={false}/>}

      {/* Modal atividade */}
      {actModal&&(
        <div style={{ position:"fixed",inset:0,background:"rgba(15,23,42,.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000,padding:16 }}
          onClick={e=>{if(e.target===e.currentTarget){setActModal(false);}}}>
          <div style={{ background:"#fff",borderRadius:20,padding:26,width:"100%",maxWidth:460,boxShadow:"0 20px 60px rgba(0,0,0,.25)" }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18 }}>
              <div style={{ fontSize:17,fontWeight:800,color:"#1e293b" }}>{editActId?"✏️ Editar Atividade":"➕ Nova Atividade"}</div>
              <button onClick={()=>setActModal(false)} style={{ width:30,height:30,borderRadius:7,border:"1px solid #e2e8f0",background:"#f8fafc",cursor:"pointer",fontSize:17,color:"#64748b",display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
            </div>
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".5px" }}>Título *</label>
                <input value={actForm.title} onChange={e=>setActForm(f=>({...f,title:e.target.value}))} placeholder="Ex: Análise financeira, Treinamento..."
                  style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:`1.5px solid ${actForm.title?"#0d9488":"#e2e8f0"}`,fontSize:13,outline:"none",boxSizing:"border-box" }}/>
              </div>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:4,textTransform:"uppercase",letterSpacing:".5px" }}>Descrição</label>
                <textarea value={actForm.desc} onChange={e=>setActForm(f=>({...f,desc:e.target.value}))} placeholder="Detalhes da atividade..." rows={3}
                  style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",resize:"vertical",boxSizing:"border-box",fontFamily:"inherit" }}/>
              </div>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>Data</label>
                <input type="date" value={actForm.data||""} onChange={e=>setActForm(f=>({...f,data:e.target.value}))}
                  style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #e2e8f0",fontSize:13,outline:"none",boxSizing:"border-box" }}/>
              </div>
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
                <div>
                  <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>▶ Hora início</label>
                  <input type="time" value={actForm.horaIni||""} onChange={e=>setActForm(f=>({...f,horaIni:e.target.value}))}
                    style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #eff6ff",fontSize:13,outline:"none",boxSizing:"border-box" }}/>
                </div>
                <div>
                  <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".5px" }}>■ Hora término</label>
                  <input type="time" value={actForm.horaFim||""} onChange={e=>setActForm(f=>({...f,horaFim:e.target.value}))}
                    style={{ width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #f0fdf4",fontSize:13,outline:"none",boxSizing:"border-box" }}/>
                </div>
              </div>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:6,textTransform:"uppercase",letterSpacing:".5px" }}>Status</label>
                <div style={{ display:"flex",gap:7 }}>
                  {Object.entries(STATUS_CFG).map(([k,v])=>(
                    <button key={k} onClick={()=>setActForm(f=>({...f,status:k}))}
                      style={{ flex:1,padding:"7px 4px",borderRadius:8,border:`2px solid ${actForm.status===k?v.dot:"#e2e8f0"}`,background:actForm.status===k?v.bg:"#f8fafc",color:actForm.status===k?v.text:"#94a3b8",cursor:"pointer",fontSize:11,fontWeight:actForm.status===k?700:500 }}>
                      {v.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ fontSize:11,fontWeight:700,color:"#64748b",display:"block",marginBottom:6,textTransform:"uppercase",letterSpacing:".5px" }}>Prazo</label>
                <div style={{ display:"flex",gap:7 }}>
                  <button onClick={()=>setActForm(f=>({...f,prazo:"agora"}))}
                    style={{ flex:1,padding:"7px 0",borderRadius:8,border:`2px solid ${actForm.prazo==="agora"?"#f59e0b":"#e2e8f0"}`,background:actForm.prazo==="agora"?"#fef3c7":"#f8fafc",color:actForm.prazo==="agora"?"#92400e":"#94a3b8",cursor:"pointer",fontSize:12,fontWeight:actForm.prazo==="agora"?700:500 }}>
                    ⏰ Agora
                  </button>
                  <button onClick={()=>setActForm(f=>({...f,prazo:"longo"}))}
                    style={{ flex:1,padding:"7px 0",borderRadius:8,border:`2px solid ${actForm.prazo==="longo"?"#2563eb":"#e2e8f0"}`,background:actForm.prazo==="longo"?"#eff6ff":"#f8fafc",color:actForm.prazo==="longo"?"#1d4ed8":"#94a3b8",cursor:"pointer",fontSize:12,fontWeight:actForm.prazo==="longo"?700:500 }}>
                    🔭 Longo prazo
                  </button>
                </div>
              </div>
              <div style={{ display:"flex",gap:8,marginTop:4 }}>
                <button onClick={()=>setActModal(false)} style={{ flex:1,padding:"10px 0",borderRadius:9,border:"1.5px solid #e2e8f0",background:"#f8fafc",color:"#64748b",cursor:"pointer",fontSize:13,fontWeight:600 }}>Cancelar</button>
                <button onClick={saveAct} disabled={!actForm.title.trim()} style={{ flex:2,padding:"10px 0",borderRadius:9,border:"none",background:actForm.title.trim()?"#0d9488":"#e2e8f0",color:"#fff",cursor:actForm.title.trim()?"pointer":"not-allowed",fontSize:13,fontWeight:700 }}>
                  {editActId?"💾 Salvar":"✅ Adicionar"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showProfile&&<ProfileModal user={person} onSave={saveProfile} onClose={()=>setShowProfile(false)}/>}
    </div>
  );
}

// ── PAINEL COLABORADOR ────────────────────────────────────────────────────
function ColabPanel({ userId, users, setUsers, events, setEvents, onLogout }) {
  const person = users[userId];
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth());
  const [view, setView] = useState("calendar");
  const [selectedDay, setSelectedDay] = useState(null);
  const [modal, setModal] = useState(false);
  const [editingEventId, setEditingEventId] = useState(null);
  const [form, setForm] = useState({title:"",description:"",time:"",priority:"media",category:""});
  const [showProfile, setShowProfile] = useState(false);

  const daysInMonth=getDaysInMonth(year,month);
  const firstDay=getFirstDay(year,month);

  function getEventsDay(day){ return events[`${userId}::${fmtKey(year,month,day)}`]||[]; }
  function openAdd(day){ setSelectedDay(day); setEditingEventId(null); setForm({title:"",description:"",time:"",priority:"media",category:""}); setModal(true); }
  function openEdit(day,ev){ if(ev.fromAdmin)return; setSelectedDay(day); setEditingEventId(ev.id); setForm({title:ev.title,description:ev.description||"",time:ev.time||"",priority:ev.priority||"media",category:ev.category||""}); setModal(true); }
  function saveEvent(){ if(!form.title.trim())return; const key=`${userId}::${fmtKey(year,month,selectedDay)}`; const ex=events[key]||[]; if(editingEventId){setEvents(p=>({...p,[key]:ex.map(e=>e.id===editingEventId?{...e,...form}:e)}))}else{setEvents(p=>({...p,[key]:[...ex,{...form,id:Date.now()}]}))} setModal(false); }
  function deleteEvent(day,id){ const key=`${userId}::${fmtKey(year,month,day)}`; setEvents(p=>({...p,[key]:(p[key]||[]).filter(e=>e.id!==id)})); setModal(false); }
  function getAllEventsMonth(){ const r=[]; for(let d=1;d<=daysInMonth;d++){ const key=`${userId}::${fmtKey(year,month,d)}`; (events[key]||[]).forEach(ev=>r.push({day:d,ev})); } return r.sort((a,b)=>a.day-b.day||(a.ev.time||"").localeCompare(b.ev.time||"")); }
  function prevMonth(){ if(month===0){setMonth(11);setYear(y=>y-1);}else setMonth(m=>m-1); }
  function nextMonth(){ if(month===11){setMonth(0);setYear(y=>y+1);}else setMonth(m=>m+1); }

  const allMonthEvents=getAllEventsMonth();
  const adminCount=allMonthEvents.filter(x=>x.ev.fromAdmin).length;

  function saveProfile({photo,status,name}){
    setUsers(p=>({...p,[userId]:{...p[userId],photo,status,name}}));
    setShowProfile(false);
  }

  return (
    <div style={{ fontFamily:"'Inter','Segoe UI',sans-serif",minHeight:"100vh",background:"#f8fafc" }}>
      <div style={{ background:"#000",padding:"0 20px",boxShadow:"0 2px 8px rgba(0,0,0,.6)" }}>
        <div style={{ maxWidth:1000,margin:"0 auto" }}>
          <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between", paddingTop:16, paddingBottom:14,flexWrap:"wrap",gap:10 }}>
            <div style={{ display:"flex",alignItems:"center",gap:12 }}>
              <Avatar user={person} size={42} onClick={()=>setShowProfile(true)}/>
              <div>
                <GrupoGomesLogo height={38}/>
                <p style={{ color:person.color,fontSize:12,margin:"4px 0 0",fontWeight:600 }}>{person.name}</p>
              </div>
            </div>
            <div style={{ display:"flex",gap:8 }}>
              <button onClick={()=>setShowProfile(true)} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:"#111",color:"#94a3b8" }}>✏️ Meu Perfil</button>
              <button onClick={()=>setView("calendar")} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:view==="calendar"?"#3b82f6":"#334155",color:view==="calendar"?"#fff":"#94a3b8" }}>📅 Calendário</button>
              <button onClick={()=>setView("list")} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:view==="list"?"#3b82f6":"#334155",color:view==="list"?"#fff":"#94a3b8" }}>📋 Lista</button>
              <button onClick={onLogout} style={{ padding:"6px 14px",borderRadius:8,border:"none",cursor:"pointer",fontSize:12,fontWeight:600,background:"#111",color:"#f87171" }}>🚪 Sair</button>
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth:1000,margin:"0 auto",padding:"20px 16px" }}>
        {/* Profile card */}
        <ProfileCard user={person} onEdit={()=>setShowProfile(true)}/>

        {adminCount>0&&(
          <div style={{ marginBottom:14,padding:"10px 16px",background:"#eff6ff",borderRadius:10,border:"1px solid #bfdbfe",fontSize:12,color:"#1d4ed8",display:"flex",alignItems:"center",gap:8 }}>
            📌 <strong>{adminCount} evento{adminCount>1?"s":""}</strong> {adminCount>1?"foram enviados":"foi enviado"} pela empresa para sua agenda neste mês.
          </div>
        )}

        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16,flexWrap:"wrap",gap:10 }}>
          <div style={{ fontSize:13,color:"#94a3b8" }}>{allMonthEvents.length} tarefa{allMonthEvents.length!==1?"s":""} em {MONTHS[month]}</div>
          <div style={{ display:"flex",alignItems:"center",gap:8 }}>
            <button onClick={prevMonth} style={{ width:34,height:34,borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center" }}>‹</button>
            <span style={{ fontWeight:700,fontSize:15,color:"#1e293b",minWidth:150,textAlign:"center" }}>{MONTHS[month]} {year}</span>
            <button onClick={nextMonth} style={{ width:34,height:34,borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:16,display:"flex",alignItems:"center",justifyContent:"center" }}>›</button>
            <button onClick={()=>{setMonth(today.getMonth());setYear(today.getFullYear());}} style={{ padding:"6px 12px",borderRadius:8,border:"1px solid #e2e8f0",background:"#fff",cursor:"pointer",fontSize:12,color:"#64748b" }}>Hoje</button>
          </div>
        </div>

        {view==="calendar"&&<CalendarGrid person={person} year={year} month={month} getEventsDay={getEventsDay} daysInMonth={daysInMonth} firstDay={firstDay} onAddDay={openAdd} onEditEvent={openEdit}/>}
        {view==="list"&&<ListView person={person} month={month} allEvents={allMonthEvents} onEdit={openEdit} onDelete={deleteEvent}/>}
      </div>

      {modal&&<TaskModal person={person} selectedDay={selectedDay} month={month} year={year} editingEvent={editingEventId} form={form} setForm={setForm} onSave={saveEvent} onDelete={()=>deleteEvent(selectedDay,editingEventId)} onClose={()=>setModal(false)} users={users} isAdmin={false}/>}
      {showProfile&&<ProfileModal user={person} onSave={saveProfile} onClose={()=>setShowProfile(false)}/>}
    </div>
  );
}

// ── ROOT ──────────────────────────────────────────────────────────────────
// ── ROOT ──────────────────────────────────────────────────────────────────
export default function App() {
  const [users, setUsers] = useState(INITIAL_USERS);
  const [events, setEvents] = useState({});
  const [loggedIn, setLoggedIn] = useState(null);
  const [clientData, setClientData] = useState({});

  if (!loggedIn) return <LoginScreen users={users} onLogin={setLoggedIn}/>;
  if (loggedIn==="admin") return <AdminPanel users={users} setUsers={setUsers} events={events} setEvents={setEvents} onLogout={()=>setLoggedIn(null)}/>;
  if (users[loggedIn]?.role==="client") return <ClientPanel userId={loggedIn} users={users} setUsers={setUsers} events={events} setEvents={setEvents} onLogout={()=>setLoggedIn(null)} clientData={clientData} setClientData={setClientData}/>;
  return <ColabPanel userId={loggedIn} users={users} setUsers={setUsers} events={events} setEvents={setEvents} onLogout={()=>setLoggedIn(null)}/>;
}
